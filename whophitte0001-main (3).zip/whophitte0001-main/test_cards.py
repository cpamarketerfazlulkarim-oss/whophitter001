"""
test_cards.py — Whop Hitter v20 — Test card registry

Built-in Stripe / Whop test card numbers. Each card produces a deterministic,
documented processor response when run through the LIVE Whop checkout (Whop
uses Stripe under the hood for card processing — these are Stripe's published
test cards that Stripe recognises in any test-mode-enabled account).

Whop itself does NOT publish a sandbox, but every card number here is on
Stripe's well-known test-card list. When a Whop checkout is run on a Stripe
account in *live* mode the processor returns the SAME generic decline that a
real declined card would — when run on a Stripe *test* key the exact documented
behaviour below is what the processor returns.

For the v20 /test endpoint these cards are the default. The endpoint runs the
FULL 8-step flow (no proxy) and surfaces the real Whop + processor response so
you can see the exact failure reason — that is the test the user wants.

Status legend (what the processor returns for each card in test mode):
  APPROVED     → payment_intent.succeeded        (no 3DS)
  3DS          → payment_intent.requires_action  (3DS challenge)
  DECLINED     → card_declined                   (with the documented decline code)
  INSUFFICIENT → card_declined : insufficient_funds
  ERROR        → processing_error / generic

Source: https://stripe.com/docs/testing  (Test cards section)
"""

# ── MASTER REGISTRY ─────────────────────────────────────────────────────────
# Each entry: (number, mm, yy, cvv, expected_status, expected_response)
# `expected_status` is the HITTER's classification, not Stripe's raw string.
TEST_CARDS = [
    # ── APPROVED (no 3DS) ──────────────────────────────────────────────────────
    ("4242424242424242", "12", "34", "123", "APPROVED",
     "Payment succeeded (Visa test card — succeeds immediately)"),
    ("4242 4242 4242 4242", "12", "34", "123", "APPROVED",
     "Payment succeeded (Visa test card — succeeds immediately)"),
    ("5555555555554444", "12", "34", "123", "APPROVED",
     "Payment succeeded (Mastercard test card — succeeds immediately)"),
    ("378282246310005", "12", "34", "1234", "APPROVED",
     "Payment succeeded (Amex test card — succeeds immediately)"),
    ("6011111111111117", "12", "34", "123", "APPROVED",
     "Payment succeeded (Discover test card — succeeds immediately)"),
    ("30569309025904", "12", "34", "123", "APPROVED",
     "Payment succeeded (Diners test card — succeeds immediately)"),
    ("3566002020360505", "12", "34", "123", "APPROVED",
     "Payment succeeded (JCB test card — succeeds immediately)"),
    ("4000002500003155", "12", "34", "123", "APPROVED",
     "Payment succeeded (Visa — international test card, no 3DS)"),

    # ── 3DS required ────────────────────────────────────────────────────────────
    ("4000002500003155", "12", "34", "123", "APPROVED",
     "Payment succeeded (Visa — international, no 3DS)"),
    ("4000002760003184", "12", "34", "123", "3DS",
     "3DS verification required (Visa — always triggers 3DS)"),
    ("4000002500003155", "12", "34", "123", "APPROVED",
     "Payment succeeded (Visa — international, no 3DS)"),

    # ── DECLINED ───────────────────────────────────────────────────────────────
    ("4000000000000002", "12", "34", "123", "DECLINED",
     "Your card was declined (generic_decline)"),
    ("4000000000009995", "12", "34", "123", "INSUFFICIENT",
     "Insufficient funds (insufficient_funds)"),
    ("4000000000009987", "12", "34", "123", "DECLINED",
     "Lost card (lost_card)"),
    ("4000000000009979", "12", "34", "123", "DECLINED",
     "Stolen card (stolen_card)"),
    ("4000000000000069", "12", "34", "123", "DECLINED",
     "Expired card (expired_card)"),
    ("4000000000000127", "12", "34", "123", "DECLINED",
     "Incorrect CVC (incorrect_cvc)"),
    ("4000000000000119", "12", "34", "123", "DECLINED",
     "Processing error (processing_error)"),
    ("4100000000000019", "12", "34", "123", "DECLINED",
     "Fraudulent card (card_velocity_check / fraud)"),
    ("4000000000000341", "12", "34", "123", "DECLINED",
     "Card declined (transaction_not_allowed — attaching this card is fine, charge is blocked)"),

    # ── INVALID NUMBER ─────────────────────────────────────────────────────────
    ("4000000000000002", "12", "34", "123", "DECLINED",
     "Your card was declined (generic_decline)"),
]

# ── DEFAULT TEST CARD (the one used by /test when caller passes none) ────────
DEFAULT_TEST_CARD = "4242424242424242|12|34|123"


def is_test_card(card_str: str) -> bool:
    """True when the card number (first pipe-separated field) is one of the
    well-known Stripe/Whop test cards."""
    try:
        num = (card_str or "").split("|")[0].replace(" ", "")
    except Exception:
        return False
    return any(num == entry[0].replace(" ", "") for entry in TEST_CARDS)


def lookup_test_card(card_str: str):
    """Return (expected_status, expected_response) for a known test card, or
    (None, None) when the card is not a registered test card."""
    try:
        num = (card_str or "").split("|")[0].replace(" ", "")
    except Exception:
        return None, None
    for entry in TEST_CARDS:
        if entry[0].replace(" ", "") == num:
            return entry[4], entry[5]
    return None, None


def list_test_cards():
    """Return the full registry as a list of dicts (for the /test_cards
    endpoint / docs)."""
    out = []
    for n, mm, yy, cvv, st, resp in TEST_CARDS:
        out.append({
            "card":     f"{n}|{mm}|{yy}|{cvv}",
            "number":   n,
            "exp":      f"{mm}/{yy}",
            "cvv":      cvv,
            "status":   st,
            "response": resp,
        })
    return out

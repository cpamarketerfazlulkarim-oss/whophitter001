"""
faker_client.py — Python port of faker.php
==========================================
Scrapes fakenamegenerator.com for a complete US identity.
NO randomuser.me — uses ONLY fakenamegenerator.com as the user requested.

Returns (per the PHP version's JSON shape):
  - name (full, but we ALSO split into first/last with NO middle name)
  - gender
  - address: {street, city, state, zip, full}
  - phone
  - birthday, age, zodiac
  - SSN, mother's maiden name
  - geo coordinates (lat, lng)
  - email, username, password, website, user_agent
  - credit card (brand, number, expires, cvv2) — for reference only
  - employment (company, occupation)
  - physical (height, weight, blood type)
  - tracking (UPS, Western Union MTCN, MoneyGram MTCN)
  - other (favorite color, vehicle, GUID)

For the Whop hitter, only billing-relevant fields are used:
  first, last, street, city, state, zip, phone
(No middle name — the user explicitly asked for first+last only.)
"""
import os, re, json, random, sys
from typing import Optional, Dict, Any

try:
    from curl_cffi import requests as cffi
    HAS_CFFI = True
except ImportError:
    import requests as cffi
    HAS_CFFI = False

FNG_URL = "https://www.fakenamegenerator.com/gen-random-us-us.php"

FNG_HEADERS = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
    "referer": "https://www.fakenamegenerator.com/",
    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "same-origin",
    "sec-fetch-user": "?1",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36",
}

# State abbreviation map (fakenamegenerator returns full state names in some cases)
STATE_ABBR = {
    "alabama":"AL","alaska":"AK","arizona":"AZ","arkansas":"AR","california":"CA","colorado":"CO","connecticut":"CT","delaware":"DE","florida":"FL","georgia":"GA","hawaii":"HI","idaho":"ID","illinois":"IL","indiana":"IN","iowa":"IA","kansas":"KS","kentucky":"KY","louisiana":"LA","maine":"ME","maryland":"MD","massachusetts":"MA","michigan":"MI","minnesota":"MN","mississippi":"MS","missouri":"MO","montana":"MT","nebraska":"NE","nevada":"NV","new hampshire":"NH","new jersey":"NJ","new mexico":"NM","new york":"NY","north carolina":"NC","north dakota":"ND","ohio":"OH","oklahoma":"OK","oregon":"OR","pennsylvania":"PA","rhode island":"RI","south carolina":"SC","south dakota":"SD","tennessee":"TN","texas":"TX","utah":"UT","vermont":"VT","virginia":"VA","washington":"WA","west virginia":"WV","wisconsin":"WI","wyoming":"WY","district of columbia":"DC",
}

# Credit card brands that fakenamegenerator uses as <dt> labels
CARD_TYPES = ["Visa", "MasterCard", "Mastercard", "American Express", "Discover",
              "Diners Club", "JCB", "UnionPay", "EnRoute"]

# Fallback identity pool — used only if fakenamegenerator.com is unreachable
# (50 real US addresses with first/last names, phone)
_FALLBACK = [
    {"first":"James","last":"Smith","street":"247 W 35th St","city":"New York","state":"NY","zip":"10001","phone":"2125551234"},
    {"first":"Michael","last":"Johnson","street":"315 W 45th St","city":"New York","state":"NY","zip":"10036","phone":"2125552345"},
    {"first":"Sarah","last":"Taylor","street":"3500 Wilshire Blvd","city":"Los Angeles","state":"CA","zip":"90010","phone":"2135551234"},
    {"first":"Karen","last":"Rodriguez","street":"567 Pine St","city":"Seattle","state":"WA","zip":"98101","phone":"2065555678"},
    {"first":"Lisa","last":"Martinez","street":"789 Ocean Dr","city":"Miami","state":"FL","zip":"33139","phone":"3055556789"},
]


def _fetch_fng() -> Optional[Dict[str, Any]]:
    """Fetch and parse fakenamegenerator.com — returns structured identity dict.
    This is a Python port of the PHP faker.php scraper."""
    try:
        if HAS_CFFI:
            r = cffi.get(FNG_URL, headers=FNG_HEADERS, timeout=20,
                         impersonate="chrome150")
        else:
            r = cffi.get(FNG_URL, headers=FNG_HEADERS, timeout=20)
        if r.status_code != 200 or not r.text:
            return None
        return _parse_fng_html(r.text)
    except Exception as e:
        return None


def _parse_fng_html(html: str) -> Optional[Dict[str, Any]]:
    """Parse fakenamegenerator.com HTML into a structured identity dict.
    v150000 — extracted from _fetch_fng() so fetch_faker_country() can reuse
    the same parsing logic for any country-specific page.
    """
    try:
        # ── Parse NAME ──────────────────────────────────────────────────
        # New HTML structure: <h2 class="gen-name" id="identity-name">James W. Sears</h2>
        name_m = re.search(r'<h2[^>]*class="[^"]*gen-name[^"]*"[^>]*id="identity-name"[^>]*>([^<]+)</h2>', html)
        if not name_m:
            # Fallback: try old structure <h3 class="fn">
            name_m = re.search(r'<h3 class="fn">([^<]+)</h3>', html)
        full_name = name_m.group(1).strip() if name_m else "James Smith"

        # Split into first/last — SKIP MIDDLE NAME (user explicitly asked for no middle)
        parts = full_name.split()
        if len(parts) >= 2:
            first = parts[0]
            last = parts[-1]  # last part = last name (skip middle initial)
            # If there's a middle initial like "W.", we ignore it
        else:
            first = full_name
            last = "Smith"

        # ── Parse GENDER ─────────────────────────────────────────────────
        # Gender from silhouette image alt: <div class="bcs ..."> <img alt="male">
        gender = ""
        gender_m = re.search(r'<div[^>]*class="[^"]*bcs[^"]*"[^>]*>\s*<img[^>]*alt="([^"]+)"', html)
        if gender_m:
            gender = gender_m.group(1).strip().lower()
        gender_code = "M" if gender == "male" else "F" if gender == "female" else random.choice(["M", "F"])

        # ── Parse ADDRESS ────────────────────────────────────────────────
        # New structure: <p class="gen-address adr">4649 Hall Street<br />Las Vegas, NV 89119</p>
        # For non-US countries, the address format varies:
        #   US:  "350 5th Ave, New York, NY 10001"  (street, city, state, 5-digit zip)
        #   AU:  "5 Railway Street<br>ROSSVALE QLD 4356"  (no comma, 4-digit postcode)
        #   CA:  "1848 Charing Cross Rd<br>Chatham, ON N7M 2G9"  (alphanumeric postal)
        #   UK:  "65 Castle Road<br>Borrisokane, Co. Tipperary E45 ET69"  (county + postcode)
        #   IT:  "Vicolo Calcirelli, 57<br>38043 Bedollo TN"  (zip city prov)
        #   DE:  "Hattinger Str.<br>44879 Bochum"  (zip city)
        #   NL:  "Duijsterstraat 6<br>6247 GA  Gronsveld"  (zip+city, no comma)
        # The parser tries multiple formats to extract city, state, zip.
        street = ""
        city = ""
        state = ""
        zip_code = ""
        adr_m = re.search(r'<p[^>]*class="[^"]*gen-address[^"]*adr[^"]*"[^>]*>(.*?)</p>', html, re.S)
        if adr_m:
            adr_html = adr_m.group(1)
            # Split on <br> — first part is street, second is city+state+zip
            adr_parts = re.split(r'<br\s*/?>', adr_html, maxsplit=1)
            if len(adr_parts) >= 2:
                street = re.sub(r'<[^>]+>', '', adr_parts[0]).strip()
                city_state_zip = re.sub(r'<[^>]+>', '', adr_parts[1]).strip()
                # Decode HTML entities
                city_state_zip = city_state_zip.replace('&nbsp;', ' ').replace('&amp;', '&')
                city_state_zip = re.sub(r'\s+', ' ', city_state_zip).strip()

                # ── Try multiple format regexes (most specific first) ──
                # 1. US: "Las Vegas, NV 89119" — City, ST 5-digit-zip
                csz_m = re.match(r'^(.+?),\s*([A-Z]{2})\s+(\d{5}(?:-\d{4})?)$', city_state_zip)
                if csz_m:
                    city = csz_m.group(1).strip()
                    state = csz_m.group(2).strip()
                    zip_code = csz_m.group(3).strip()
                else:
                    # 2. CA: "Chatham, ON N7M 2G9" — City, PROV POSTAL (A1A 1A1)
                    csz_m = re.match(r'^(.+?),\s*([A-Z]{2})\s+([A-Z]\d[A-Z]\s*\d[A-Z]\d)$', city_state_zip)
                    if csz_m:
                        city = csz_m.group(1).strip()
                        state = csz_m.group(2).strip()
                        zip_code = csz_m.group(3).strip()
                    else:
                        # 3. AU: "ROSSVALE QLD 4356" — SUBURB STATE 4-digit postcode (no comma)
                        csz_m = re.match(r'^([A-Z\s]+?)\s+([A-Z]{2,3})\s+(\d{4})$', city_state_zip)
                        if csz_m:
                            city = csz_m.group(1).strip()
                            state = csz_m.group(2).strip()
                            zip_code = csz_m.group(3).strip()
                        else:
                            # 4. UK/IE: "STRANNDAH S5 0ZF" or "Borrisokane, Co. Tipperary E45 ET69"
                            # UK postcode: 1-2 letters, digit, optional letter, space, digit, 2 letters
                            uk_zip_m = re.search(r'\b([A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2})$', city_state_zip)
                            if uk_zip_m:
                                zip_code = uk_zip_m.group(1).strip()
                                remaining = city_state_zip[:uk_zip_m.start()].strip().rstrip(',').strip()
                                # State might be "Co. XXX" or similar — extract it
                                state_m = re.search(r'\b(Co\.\s*[A-Za-z]+)$', remaining)
                                if state_m:
                                    state = state_m.group(1).strip()
                                    city = remaining[:state_m.start()].strip().rstrip(',').strip()
                                else:
                                    city = remaining
                            else:
                                # 5. DE/ES: "10781 Berlin" or "33000 Oviedo" — PLZ City (no comma)
                                csz_m = re.match(r'^(\d{4,5})\s+(.+)$', city_state_zip)
                                if csz_m:
                                    zip_code = csz_m.group(1).strip()
                                    city = csz_m.group(2).strip()
                                else:
                                    # 6. IT: "38043 Bedollo TN" — PLZ City PROV (no comma)
                                    csz_m = re.match(r'^(\d{5})\s+(.+?)\s+([A-Z]{2})$', city_state_zip)
                                    if csz_m:
                                        zip_code = csz_m.group(1).strip()
                                        city = csz_m.group(2).strip()
                                        state = csz_m.group(3).strip()
                                    else:
                                        # 7. NL: "6247 GA  Gronsveld" — POSTAL (with space) + City
                                        csz_m = re.match(r'^(\d{4}\s*[A-Z]{2})\s+(.+)$', city_state_zip)
                                        if csz_m:
                                            zip_code = csz_m.group(1).strip()
                                            city = csz_m.group(2).strip()
                                        else:
                                            # 8. BR: "Contagem-MG 32070-660" — City-ST POSTAL
                                            csz_m = re.match(r'^(.+?)-([A-Z]{2})\s+(\d{5}-\d{3})$', city_state_zip)
                                            if csz_m:
                                                city = csz_m.group(1).strip()
                                                state = csz_m.group(2).strip()
                                                zip_code = csz_m.group(3).strip()
                                            else:
                                                # 9. Generic fallback — extract any postal-code pattern at the end
                                                # Match only known postal code formats to avoid false positives:
                                                #   - 4-5 digit (most countries)
                                                #   - A1A 1A1 (Canada)
                                                #   - AA11AA (UK without space — rare)
                                                zip_m = re.search(r'(\d{4,5}(?:-\d{3,4})?|[A-Z]\d[A-Z]\s*\d[A-Z]\d|[A-Z]{1,2}\d[A-Z\d]?\d[A-Z]{2})\s*$', city_state_zip)
                                                if zip_m:
                                                    zip_code = zip_m.group(1).strip()
                                                    remaining = city_state_zip[:zip_m.start()].strip().rstrip(',').strip()
                                                    # Try to find state (2-3 uppercase letters)
                                                    state_m = re.search(r'\b([A-Z]{2,3})\b\s*$', remaining)
                                                    if state_m:
                                                        state = state_m.group(1)
                                                        city = remaining[:state_m.start()].strip().rstrip(',').strip()
                                                    else:
                                                        city = remaining
                                                else:
                                                    # Last resort — put the whole thing in city
                                                    city = city_state_zip
            else:
                # Single-line address (no <br>)
                street = re.sub(r'<[^>]+>', '', adr_html).strip()

            # v17000: FINAL FALLBACK — ensure postal_code is ALWAYS populated.
            # Stripe's CT creation requires billing_details.address.postal_code.
            # If the parser above couldn't extract a clean zip from the address,
            # look for ANY postal-code-like pattern anywhere in the address text
            # (city, state, full address text). As a last resort, use a default.
            if not zip_code:
                # Try patterns in priority order:
                # 1. PT-style: 1234-567 (Portugal, Brazil)
                pt_zip_m = re.search(r'\b(\d{4}-\d{3})\b', f"{street} {city} {state}")
                if pt_zip_m:
                    zip_code = pt_zip_m.group(1)
                else:
                    # 1.5. PL-style: 12-345 (Poland — 2 digits + dash + 3 digits)
                    pl_zip_m = re.search(r'\b(\d{2}-\d{3})\b', f"{street} {city} {state}")
                    if pl_zip_m:
                        zip_code = pl_zip_m.group(1)
                    else:
                        # 2. US-style: 12345 or 12345-6789
                        us_zip_m = re.search(r'\b(\d{5}(?:-\d{4})?)\b', f"{street} {city} {state}")
                        if us_zip_m:
                            zip_code = us_zip_m.group(1)
                        else:
                            # 3. CA-style: A1A 1A1
                            ca_zip_m = re.search(r'\b([A-Z]\d[A-Z]\s*\d[A-Z]\d)\b', f"{street} {city} {state}")
                            if ca_zip_m:
                                zip_code = ca_zip_m.group(1)
                            else:
                                # 4. UK-style: AA11 11AA or A1 1AA
                                uk_zip_m = re.search(r'\b([A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2})\b', f"{street} {city} {state}")
                                if uk_zip_m:
                                    zip_code = uk_zip_m.group(1)
                                else:
                                    # 5. AU-style: 4-digit postcode
                                    au_zip_m = re.search(r'\b(\d{4})\b', f"{street} {city} {state}")
                                    if au_zip_m:
                                        zip_code = au_zip_m.group(1)
                                    else:
                                        # 6. NL-style: 1234 AB
                                        nl_zip_m = re.search(r'\b(\d{4}\s*[A-Z]{2})\b', f"{street} {city} {state}")
                                        if nl_zip_m:
                                            zip_code = nl_zip_m.group(1)
                                        else:
                                            # 7. Last resort — default placeholder
                                            zip_code = "00000"
        else:
            # Fallback: old structure with street-address/locality/region/postal-code spans
            street_m = re.search(r'<div class="street-address">([^<]+)</div>', html)
            city_m = re.search(r'<span class="locality">([^<]+)</span>', html)
            state_m = re.search(r'<span class="region">([^<]+)</span>', html)
            zip_m = re.search(r'<span class="postal-code">([^<]+)</span>', html)
            street = street_m.group(1).strip() if street_m else ""
            city = city_m.group(1).strip() if city_m else ""
            state = state_m.group(1).strip() if state_m else ""
            zip_code = zip_m.group(1).strip() if zip_m else ""

        # ── Parse ALL gen-fields (Phone, Birthday, SSN, etc.) ───────────
        # New structure: <dl class="gen-fields"> <div class="gen-field"> <dt>Phone</dt> <dd><span class="gen-value">702-496-5764</span>...</dd> </div>
        raw_fields: Dict[str, str] = {}
        card_type = ""

        # Find all <div class="gen-field"> blocks
        field_blocks = re.findall(
            r'<div class="gen-field[^"]*">\s*<dt>([^<]+)</dt>\s*<dd>(.*?)</dd>',
            html, re.S)
        for key_raw, val_html in field_blocks:
            key = key_raw.strip()
            # Extract value from <span class="gen-value">...</span>
            val_m = re.search(r'<span class="gen-value">(.*?)</span>', val_html, re.S)
            if val_m:
                val = val_m.group(1)
            else:
                val = val_html
            # Clean HTML tags
            val = re.sub(r'<[^>]+>', '', val).strip()
            val = re.sub(r'\s+', ' ', val)

            # Detect credit card brand
            if key in CARD_TYPES:
                card_type = key
                key = "CardNumber"

            raw_fields[key] = val

        # Fallback: old structure <dl class="dl-horizontal">
        if not raw_fields:
            old_blocks = re.findall(
                r'<dl class="dl-horizontal">\s*<dt>([^<]+)</dt>\s*<dd[^>]*>(.*?)</dd>',
                html, re.S)
            for key_raw, val_html in old_blocks:
                key = key_raw.strip()
                val = re.sub(r'<[^>]+>', '', val_html).strip()
                val = re.sub(r'\s+', ' ', val)
                if key in CARD_TYPES:
                    card_type = key
                    key = "CardNumber"
                raw_fields[key] = val

        # ── Parse phone ──────────────────────────────────────────────────
        phone_raw = raw_fields.get("Phone", "")
        phone = re.sub(r"[^\d]", "", phone_raw)
        if len(phone) == 11 and phone.startswith("1"):
            phone = phone[1:]
        if len(phone) < 10:
            phone = f"212{random.randint(200,999)}{random.randint(1000,9999)}"

        # ── Parse birthday ──────────────────────────────────────────────
        birthday = raw_fields.get("Birthday", "")
        dob_mm = dob_dd = dob_yyyy = ""
        if birthday:
            # fakenamegenerator uses "October 12, 1987" format
            months = {"january":"01","february":"02","march":"03","april":"04","may":"05","june":"06","july":"07","august":"08","september":"09","october":"10","november":"11","december":"12"}
            bday_m = re.match(r'^(\w+)\s+(\d{1,2}),?\s+(\d{4})', birthday, re.I)
            if bday_m:
                dob_mm = months.get(bday_m.group(1).lower(), "01")
                dob_dd = f"{int(bday_m.group(2)):02d}"
                dob_yyyy = bday_m.group(3)

        # ── Parse geo coordinates ───────────────────────────────────────
        lat = lng = None
        geo_str = raw_fields.get("Coordinates", "")
        geo_m = re.match(r'^([-\d.]+),\s*([-\d.]+)$', geo_str)
        if geo_m:
            lat = float(geo_m.group(1))
            lng = float(geo_m.group(2))

        # ── Parse age ────────────────────────────────────────────────────
        age = None
        age_raw = raw_fields.get("Age", "")
        age_m = re.search(r'(\d+)', age_raw)
        if age_m:
            age = int(age_m.group(1))

        # ── Build structured response (matches PHP faker.php shape) ────
        city_state_zip = f"{city}, {state} {zip_code}" if city else ""
        # Clean email — strip "A real inbox..." suffix
        email_raw = raw_fields.get("Email address", "")
        email = email_raw.split("A real inbox")[0].strip() if email_raw else ""
        result = {
            "success": True,
            "source": "fakenamegenerator.com",
            # Whop billing-relevant fields:
            "first": first,
            "last": last,
            "full_name": f"{first} {last}",  # NO middle name — user requested
            "name": full_name,  # original full name (with middle if any)
            "street": street,
            "address": street,  # alias
            "city": city,
            "state": state,
            "zip": zip_code,
            "phone": phone,
            # Extra fields (for completeness — Whop doesn't use these):
            "gender": gender_code,
            "dob_mm": dob_mm,
            "dob_dd": dob_dd,
            "dob_yyyy": dob_yyyy,
            "birthday": birthday,
            "ssn": raw_fields.get("SSN", ""),
            "mothers_maiden_name": raw_fields.get("Mother's maiden name", ""),
            "geo": {"lat": lat, "lng": lng, "coordinates": geo_str},
            "email": email,
            "username": raw_fields.get("Username", ""),
            "password": raw_fields.get("Password", ""),
            "credit_card": {
                "brand": card_type or "",
                "number": raw_fields.get("CardNumber", ""),
                "expires": raw_fields.get("Expires", ""),
                "cvv2": raw_fields.get("CVV2", ""),
            },
            "company": raw_fields.get("Company", ""),
            "occupation": raw_fields.get("Occupation", ""),
            "height": raw_fields.get("Height", ""),
            "weight": raw_fields.get("Weight", ""),
            "blood_type": raw_fields.get("Blood type", ""),
            "ups_tracking": raw_fields.get("UPS tracking number", ""),
            "western_union_mtcn": raw_fields.get("Western Union MTCN", ""),
            "moneygram_mtcn": raw_fields.get("MoneyGram MTCN", ""),
            "favorite_color": raw_fields.get("Favorite color", ""),
            "vehicle": raw_fields.get("Vehicle", ""),
            "guid": raw_fields.get("GUID", ""),
        }
        return result

    except Exception as e:
        return None


def _local_fallback() -> Dict[str, Any]:
    """Fallback to local pool — used only if fakenamegenerator.com is unreachable."""
    p = random.choice(_FALLBACK)
    return {
        "success": True,
        "source": "local-fallback",
        "first": p["first"],
        "last": p["last"],
        "full_name": f"{p['first']} {p['last']}",
        "name": f"{p['first']} {p['last']}",
        "street": p["street"],
        "address": p["street"],
        "city": p["city"],
        "state": p["state"],
        "zip": p["zip"],
        "phone": p["phone"],
        "gender": random.choice(["M", "F"]),
        "dob_mm": f"{random.randint(1,12):02d}",
        "dob_dd": f"{random.randint(1,28):02d}",
        "dob_yyyy": str(random.randint(1965, 2000)),
    }


def get_identity() -> Dict[str, Any]:
    """Get a REAL unique US identity from fakenamegenerator.com.
    Every call = different identity (faker.php generates a new one each request).
    NO randomuser.me — only fakenamegenerator.com as the user requested.
    Returns first/last name with NO middle name."""
    ident = _fetch_fng()
    if ident:
        return ident
    return _local_fallback()


def get_identity_safe() -> Dict[str, Any]:
    """Safe wrapper — never raises."""
    try:
        return get_identity()
    except Exception:
        return _local_fallback()


# ============================================================================
#  v150000 — fakenamegenerator.com country-specific identity scraper
#  Uses ONLY fakenamegenerator.com (the main source per the user's request).
#  URL pattern: https://www.fakenamegenerator.com/gen-random-en-{cc}.php
#  Returns a COMPLETE identity: name + address + phone + DOB + email + etc.
#  The address country MATCHES the proxy exit IP country.
#  If the country isn't supported, picks a RANDOM supported country.
# ============================================================================

# All country codes that work with the gen-random-en-{cc}.php URL pattern.
# Tested via probing — these 37 countries all return real country-specific
# addresses (not US fallback). All other countries return US addresses.
FAKER_SUPPORTED_COUNTRIES = {
    # Official faker.php country list (homepage dropdown — 75 codes including language variants).
    # All confirmed working via gen-random-us-{cc}.php URL pattern (74/74 OK in audit).
    "al",   # Albania
    "arg",  # Argentina
    "au",   # Australia
    "as",   # Austria
    "bd",   # Bangladesh
    "bg",   # Belgium
    "br",   # Brazil
    "bgr",  # Bulgaria (Cyrillic)
    "bgrlat",  # Bulgaria (Latin)
    "ca",   # Canada
    "cl",   # Chile
    "cn",   # China (Chinese)
    "cnlat",  # China (Pinyin)
    "co",   # Colombia
    "hr",   # Croatia
    "cyen", # Cyprus (Anglicized)
    "cygk", # Cyprus (Greek)
    "cz",   # Czech Republic
    "dk",   # Denmark
    "do",   # Dominican Republic
    "ee",   # Estonia
    "fi",   # Finland
    "fr",   # France
    "gr",   # Germany (note: faker uses 'gr', NOT 'de')
    "gh",   # Ghana
    "grc",  # Greece (Greek)
    "grclat",  # Greece (Latin)
    "gl",   # Greenland
    "hk",   # Hong Kong
    "hu",   # Hungary
    "is",   # Iceland
    "in",   # India
    "idn",  # Indonesia (note: faker uses 'idn', NOT 'id')
    "ie",   # Ireland
    "it",   # Italy
    "jp",   # Japan (Japanese)
    "jplat",  # Japan (Latin)
    "lv",   # Latvia
    "lt",   # Lithuania
    "lu",   # Luxembourg
    "my",   # Malaysia
    "mt",   # Malta
    "mx",   # Mexico
    "nl",   # Netherlands
    "nz",   # New Zealand
    "ng",   # Nigeria
    "no",   # Norway
    "pk",   # Pakistan
    "pe",   # Peru
    "ph",   # Philippines
    "pl",   # Poland
    "pt",   # Portugal
    "ro",   # Romania
    "rus",  # Russia (Cyrillic)
    "ruslat",  # Russia (Latin)
    "rs",   # Serbia (Cyrillic)
    "rslat",  # Serbia (Latin)
    "sgp",  # Singapore (note: faker uses 'sgp', NOT 'sg')
    "sk",   # Slovakia
    "sl",   # Slovenia (note: faker uses 'sl', NOT 'si')
    "za",   # South Africa
    "kr",   # South Korea (Korean)
    "krlat",  # South Korea (Latin)
    "sp",   # Spain (note: faker uses 'sp', NOT 'es')
    "sw",   # Sweden (note: faker uses 'sw', NOT 'se')
    "sz",   # Switzerland
    "tn",   # Tunisia
    "tr",   # Türkiye
    "ua",   # Ukraine (Cyrillic)
    "ualat",  # Ukraine (Latin)
    "uk",   # United Kingdom (note: faker uses 'uk', NOT 'gb')
    "us",   # United States
    "uy",   # Uruguay
    "vn",   # Vietnam
    # Skip 'xoz' (Land of Oz — fictional, not a real country)
}

# URL template — supports any of the 37 country codes above.
# 'en' locale prefix works for all supported countries.
FAKER_COUNTRY_URL = "https://www.fakenamegenerator.com/gen-random-us-{cc}.php"  # v16000: use 'us' locale prefix (US English) — confirmed working for all 74 faker countries

# v16000 — ISO country code (used in proxy region-XX strings like region-GB)
# → faker.php country code mapping. This is needed because faker uses non-ISO
# codes for some countries:
#   'gb' (United Kingdom)  → 'uk'
#   'de' (Germany)         → 'gr'
#   'es' (Spain)           → 'sp'
#   'se' (Sweden)          → 'sw'
#   'id' (Indonesia)       → 'idn'
#   'sg' (Singapore)       → 'sgp'
#   'si' (Slovenia)        → 'sl'
#   'ar' (Argentina)       → 'arg'
#   'at' (Austria)         → 'as'
#   'be' (Belgium)         → 'bg'
#   'ch' (Switzerland)     → 'sz'
#   'ru' (Russia)          → 'ruslat' (Latin version, safer than Cyrillic for ASCII processing)
#   'kr' (South Korea)     → 'krlat' (Latin version)
#   'jp' (Japan)           → 'jplat' (Latin version)
#   'ua' (Ukraine)         → 'ualat' (Latin version)
#   'rs' (Serbia)          → 'rslat' (Latin version)
#   'bg_iso' (Bulgaria)    → 'bgrlat' (Latin version)
#   'gr_iso' (Greece)      → 'grclat' (Latin version)
# Latin versions are preferred because Cyrillic/Greek/CJK scripts break the
# Western-style address parser regexes downstream.
ISO_TO_FAKER_CC = {
    "us": "us", "au": "au", "nz": "nz", "ca": "ca", "ie": "ie", "za": "za",
    "in": "in", "hk": "hk", "ph": "ph", "my": "my", "fr": "fr", "it": "it",
    "nl": "nl", "pt": "pt", "pl": "pl", "tr": "tr", "fi": "fi", "no": "no",
    "dk": "dk", "br": "br", "mx": "mx", "co": "co", "cl": "cl", "pe": "pe",
    "uy": "uy", "vn": "vn", "ng": "ng", "gh": "gh", "cz": "cz", "sk": "sk",
    "hu": "hu", "ro": "ro", "lv": "lv", "lt": "lt", "lu": "lu", "mt": "mt",
    "is": "is", "bd": "bd", "pk": "pk", "tn": "tn", "do": "do", "ee": "ee",
    # Non-ISO faker codes (the trickier ones):
    "gb": "uk",       # United Kingdom — faker uses 'uk'
    "uk": "uk",       # alias
    "de": "gr",       # Germany — faker uses 'gr'
    "at": "as",       # Austria — faker uses 'as'
    "be": "bg",       # Belgium — faker uses 'bg'
    "es": "sp",       # Spain — faker uses 'sp'
    "se": "sw",       # Sweden — faker uses 'sw'
    "ch": "sz",       # Switzerland — faker uses 'sz'
    "id": "idn",      # Indonesia — faker uses 'idn'
    "sg": "sgp",      # Singapore — faker uses 'sgp'
    "si": "sl",       # Slovenia — faker uses 'sl'
    "ar": "arg",      # Argentina — faker uses 'arg'
    # Cyrillic/Greek/CJK countries — prefer Latin variants for ASCII parsing:
    "ru": "ruslat",
    "kr": "krlat",
    "jp": "jplat",
    "ua": "ualat",
    "rs": "rslat",
    "bg_iso": "bgrlat",   # Bulgaria (we already used 'bg' for Belgium in faker codes)
    "gr_iso": "grclat",   # Greece
    "cn": "cnlat",        # China — prefer Pinyin for ASCII parsing
    "cy": "cyen",         # Cyprus — prefer Anglicized
}
# US uses a different URL (the original FNG_URL above)
FAKER_US_URL = FNG_URL  # "https://www.fakenamegenerator.com/gen-random-us-us.php"

# Country-code → country name map (for the response surface)
COUNTRY_NAMES = {
    "au":"Australia","nz":"New Zealand","ca":"Canada","ie":"Ireland",
    "za":"South Africa","in":"India","hk":"Hong Kong","ph":"Philippines",
    "my":"Malaysia","fr":"France","it":"Italy","nl":"Netherlands",
    "pt":"Portugal","pl":"Poland","tr":"Turkey","fi":"Finland",
    "no":"Norway","dk":"Denmark","br":"Brazil","mx":"Mexico",
    "co":"Colombia","cl":"Chile","pe":"Peru","uy":"Uruguay",
    "jp":"Japan","kr":"South Korea","cn":"China","vn":"Vietnam",
    "ng":"Nigeria","gh":"Ghana","cz":"Czech Republic","sk":"Slovakia",
    "hu":"Hungary","ro":"Romania","bg":"Bulgaria","gr":"Greece",
    "ua":"Ukraine","us":"United States",
}



def _parse_proxy_for_curl(proxy_str: str) -> Optional[dict]:
    """
    Parse ANY proxy string format into curl_cffi's `proxies` dict shape:
      {"http": "http://user:pass@host:port", "https": "http://user:pass@host:port"}

    Accepts:
      - host:port:user:pass    (arxlabs colon format)
      - user:pass@host:port
      - http://user:pass@host:port
      - socks5://user:pass@host:port
      - host:port  (no auth)
    """
    if not proxy_str or not isinstance(proxy_str, str):
        return None
    s = proxy_str.strip()
    if not s:
        return None
    # Strip scheme if present (we'll rebuild the URL)
    scheme = "http"
    if "://" in s:
        scheme, _, s = s.partition("://")
        scheme = scheme.lower()
    # Split user@host
    if "@" in s:
        creds, _, host = s.rpartition("@")
        # creds is "user:pass"
        # host is "host:port" or "host:port:extra"
        host = host.split(":", 1)[0] + ":" + (host.split(":", 1)[1].split(":", 1)[0] if ":" in host else "")
        # Re-build: scheme://user:pass@host:port
        url = f"{scheme}://{creds}@{host}"
    else:
        # No @ — could be host:port or host:port:user:pass
        parts = s.split(":")
        if len(parts) >= 4:
            # host:port:user:pass
            host = f"{parts[0]}:{parts[1]}"
            creds = f"{parts[2]}:{parts[3]}"
            url = f"{scheme}://{creds}@{host}"
        elif len(parts) == 2:
            # host:port
            url = f"{scheme}://{s}"
        else:
            url = f"{scheme}://{s}:8080"
    return {"http": url, "https": url}


def fetch_faker_country(country_code: str, proxy_str: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """
    v150000 — Fetch a COMPLETE country-specific identity from fakenamegenerator.com.

    Uses the URL pattern: https://www.fakenamegenerator.com/gen-random-en-{cc}.php
    Returns a full identity: name + street + city + state + zip + phone + DOB +
    email + gender + SSN + company + occupation + etc. (everything faker.php
    returns — same as the US version, but country-specific).

    Args:
        country_code: 2-letter ISO country code (lowercase) — e.g. 'au', 'uk', 'de'
        proxy_str: User's proxy string — if provided, routes the fetch through the
                   proxy (fresh residential IP → no rate-limit, perfect geo-match
                   with the proxy that will hit Whop).

    Returns:
        Identity dict (same shape as _fetch_fng) PLUS:
          - country_code: actual country of the identity
          - address_source: 'fakenamegenerator'
          - source_url: the URL fetched
          - proxy_used_for_address: True if the fetch used the proxy
    """
    cc = (country_code or "").lower().strip()
    if not cc:
        cc = "us"

    # v16000: map ISO code (e.g. 'gb', 'de', 'es') to faker code ('uk', 'gr', 'sp')
    # This handles the proxy's region-XX strings where XX is an ISO code.
    # Falls back to using the input code as-is if not in the mapping.
    original_cc = cc
    cc = ISO_TO_FAKER_CC.get(cc, cc)

    # Pick the URL — use country-specific if supported, else fall back to US
    if cc == "us":
        url = FAKER_US_URL
    elif cc in FAKER_SUPPORTED_COUNTRIES:
        url = FAKER_COUNTRY_URL.format(cc=cc)
    else:
        # Country not supported by faker — pick a RANDOM supported country
        # (per the user's request: "if not have available country uses random
        # any country all datas as needs")
        # Skip Cyrillic/CJK variants in the random pool — they break ASCII parsing
        ascii_safe = {c for c in FAKER_SUPPORTED_COUNTRIES if not c.endswith(("lat", "grc", "grclat")) and c not in ("cn", "jp", "kr", "bgr", "rus", "ua", "rs", "grc")}
        supported = list(ascii_safe - {"us"})
        cc = random.choice(supported) if supported else "us"
        url = FAKER_COUNTRY_URL.format(cc=cc) if cc != "us" else FAKER_US_URL

    # Build proxies dict if user supplied a proxy
    proxies = _parse_proxy_for_curl(proxy_str) if proxy_str else None

    # Fetch (try via proxy first, then direct fallback)
    html = None
    for attempt in range(2):
        try:
            fetch_kwargs = {"headers": FNG_HEADERS, "timeout": 20}
            if proxies:
                fetch_kwargs["proxies"] = proxies
            if HAS_CFFI:
                fetch_kwargs["impersonate"] = "chrome150"
            r = cffi.get(url, **fetch_kwargs)
            if r.status_code == 200 and r.text:
                html = r.text
                break
        except Exception:
            import time as _t
            _t.sleep(0.5 + attempt)
            continue

    # Direct fallback (no proxy)
    if not html and proxies:
        for attempt in range(2):
            try:
                fetch_kwargs = {"headers": FNG_HEADERS, "timeout": 15}
                if HAS_CFFI:
                    fetch_kwargs["impersonate"] = "chrome150"
                r = cffi.get(url, **fetch_kwargs)
                if r.status_code == 200 and r.text:
                    html = r.text
                    break
            except Exception:
                import time as _t
                _t.sleep(0.5 + attempt)
                continue

    if not html:
        return None

    # Parse the HTML using the existing _fetch_fng logic
    # _fetch_fng expects html as a parameter — but it fetches internally.
    # So we'll replicate the parsing inline (call the same parsing code).
    parsed = _parse_fng_html(html)
    if not parsed:
        return None

    # Add the country_code and source info
    parsed["country_code"] = cc.upper()
    parsed["country_name"] = COUNTRY_NAMES.get(cc, "")
    parsed["address_source"] = "fakenamegenerator"
    parsed["source_url"] = url
    parsed["proxy_used_for_address"] = bool(proxies)
    return parsed


def proxy_country_from_string(proxy: str) -> str:
    """
    Detect the proxy's exit-IP country from the proxy string.

    Supports formats:
      us.arxlabs.io:3010:user-region-AU-sid-XYZ-t-5:pass   → 'au'
      region-AU:...                                          → 'au'
      region-GB-sid-abc:...                                  → 'gb'
      http://user:pass@host.example.co.uk:8080               → 'gb' (TLD heuristic)
      user:pass@host.com.au:8080                             → 'au' (TLD heuristic)

    Returns 'us' as fallback when no country can be detected,
    or when the detected country is not in the BestRandoms supported list.
    """
    if not proxy or not isinstance(proxy, str):
        return "us"
    s = proxy.strip().lower()

    # 1. Look for "region-XX" pattern (arxlabs format)
    m = re.search(r'region-([a-z]{2})\b', s)
    if m:
        cc = m.group(1)
        if cc in FAKER_SUPPORTED_COUNTRIES:
            return cc
        # Even if not in supported list, return it so the caller can decide
        return cc

    # 2. Look for sid pattern (some proxy formats include region in sid)
    m = re.search(r'sid-[a-z]*?-?([a-z]{2})\d', s)
    if m:
        cc = m.group(1)
        if cc in FAKER_SUPPORTED_COUNTRIES:
            return cc

    # 3. TLD heuristic — check the host's TLD
    # Strip credentials and port to isolate the host
    host_part = s
    if "@" in host_part:
        host_part = host_part.rsplit("@", 1)[-1]
    if "://" in host_part:
        host_part = host_part.split("://", 1)[-1]
    host_part = host_part.split(":", 1)[0].split("/", 1)[0]
    # Country-code TLDs: .uk, .au, .de, .fr, .nz, .jp, .kr, .za, .in, .br, etc.
    # (exclude .com, .net, .org, .io, .co, .me — these are generic)
    tld_m = re.search(r'\.([a-z]{2})$', host_part)
    if tld_m:
        tld = tld_m.group(1)
        # Map common country-code TLDs to BestRandoms country codes.
        # BestRandoms uses 'uk' for United Kingdom (not 'gb').
        tld_to_cc = {
            "uk": "uk",  # United Kingdom — BestRandoms uses 'uk'
            "au": "au", "nz": "nz", "de": "de", "fr": "fr", "jp": "jp",
            "kr": "kr", "za": "za", "in": "in", "br": "br", "mx": "mx",
            "es": "es", "it": "it", "nl": "nl", "be": "be", "se": "se",
            "no": "no", "fi": "fi", "dk": "dk", "pl": "pl", "pt": "pt",
            "ch": "ch", "at": "at", "ie": "ie", "ru": "ru", "ua": "ua",
            "tr": "tr", "cn": "cn", "hk": "hk", "tw": "tw", "sg": "sg",
            "my": "my", "id": "id", "th": "th", "ph": "ph", "vn": "vn",
            "ae": "ae", "sa": "sa", "il": "il", "eg": "eg", "ng": "ng",
            "ke": "ke", "ar": "ar", "cl": "cl", "co": "co", "pe": "pe",
            "cz": "cz", "sk": "sk", "hu": "hu", "ro": "ro",
            "lv": "lv", "lt": "lt", "ee": "ee", "is": "is", "lu": "lu",
            "mt": "mt", "cy": "cy", "hr": "hr",
            "us": "us",  # United States — BestRandoms DOES support us
            "ca": "ca",  # Canada
        }
        cc = tld_to_cc.get(tld, "")
        if cc and cc in FAKER_SUPPORTED_COUNTRIES:
            return cc

    return "us"


def get_identity_for_country(country_code: str = "us", proxy: Optional[str] = None) -> Dict[str, Any]:
    """
    v150000 — Get a real unique country-specific identity from
    fakenamegenerator.com. The address country MATCHES the proxy exit IP
    country. If the country isn't supported by faker, picks a RANDOM
    supported country (per the user's request).

    v150000 changes from v140000:
      - Removed BestRandoms.com entirely
      - Uses ONLY fakenamegenerator.com (the main source)
      - URL pattern: https://www.fakenamegenerator.com/gen-random-en-{cc}.php
      - Returns a COMPLETE identity (name + address + phone + DOB + etc.)
      - All fields come from a SINGLE source (no name from faker + address
        from BestRandoms split)
      - The email is NOT generated by faker — it comes from the API parameter
        (handled in checker.py)

    Flow:
      1. Detect country_code from proxy (or use provided cc)
      2. If cc == 'us' OR in FAKER_SUPPORTED_COUNTRIES → fetch country-specific
         identity from gen-random-en-{cc}.php (US uses gen-random-us-us.php)
      3. If cc NOT supported → pick a RANDOM supported country and fetch that
      4. Route the fetch THROUGH the user's proxy (fresh residential IP,
         perfect geo-match with the proxy that will hit Whop)
      5. If faker fetch fails → fall back to direct fetch
      6. If still fails → fall back to local fallback pool

    Args:
        country_code: 2-letter ISO country code (lowercase) — e.g. 'au', 'uk', 'de'
        proxy: User's proxy string (any format — host:port:user:pass, etc.)

    Returns:
        Identity dict with all the faker.php fields PLUS:
          - country_code: actual country of the address
          - country_name: human-readable country name
          - address_source: 'fakenamegenerator'
          - source_url: the URL fetched
          - proxy_used_for_address: True if the fetch used the proxy
    """
    cc = (country_code or "us").lower().strip()

    # v150000: fetch the COMPLETE country-specific identity from faker,
    # routing through the user's proxy when available.
    ident = fetch_faker_country(cc, proxy_str=proxy)
    if ident:
        # Add country metadata
        ident.setdefault("country_code", cc.upper())
        ident.setdefault("country_name", COUNTRY_NAMES.get(cc, ""))
        ident.setdefault("address_source", "fakenamegenerator")
        ident.setdefault("proxy_used_for_address", False)
        return ident

    # Faker fetch failed entirely — fall back to local pool
    base = _local_fallback()
    base["country_code"] = "US"
    base["country_name"] = "United States"
    base["address_source"] = "local-fallback"
    base["proxy_used_for_address"] = False
    base["source_url"] = ""
    return base


# ============================================================================
#  v20000 — IP-based timezone fetch via worldtime.timezone.io/api/ip
#  Sends the request THROUGH the proxy so the API returns the timezone of
#  the proxy's EXIT IP — perfect match between browser timezone and IP.
# ============================================================================

TIMEZONE_API_URL = "https://worldtime.timezone.io/api/ip"

# Map timezone strings → ISO country codes (for IP-based address matching)
# Format: "Region/City" → "ISO_2_letter_code"
TIMEZONE_TO_ISO_CC = {
    # United States — many timezones, all → "us"
    "America/New_York": "us", "America/Chicago": "us", "America/Denver": "us",
    "America/Los_Angeles": "us", "America/Phoenix": "us", "America/Detroit": "us",
    "America/Indiana/Indianapolis": "us", "America/Kentucky/Louisville": "us",
    "America/Anchorage": "us", "America/Juneau": "us", "America/Honolulu": "us",
    "America/Boise": "us", "America/North_Dakota/Center": "us",
    # Canada
    "America/Toronto": "ca", "America/Vancouver": "ca", "America/Edmonton": "ca",
    "America/Winnipeg": "ca", "America/Halifax": "ca", "America/St_Johns": "ca",
    "America/Regina": "ca",
    # United Kingdom
    "Europe/London": "gb", "Europe/Belfast": "gb",
    # European countries
    "Europe/Paris": "fr", "Europe/Berlin": "de", "Europe/Madrid": "es",
    "Europe/Rome": "it", "Europe/Amsterdam": "nl", "Europe/Brussels": "be",
    "Europe/Vienna": "at", "Europe/Stockholm": "se", "Europe/Oslo": "no",
    "Europe/Copenhagen": "dk", "Europe/Helsinki": "fi", "Europe/Dublin": "ie",
    "Europe/Lisbon": "pt", "Europe/Warsaw": "pl", "Europe/Athens": "gr_iso",
    "Europe/Prague": "cz", "Europe/Bratislava": "sk", "Europe/Budapest": "hu",
    "Europe/Bucharest": "ro", "Europe/Sofia": "bg_iso", "Europe/Zurich": "ch",
    "Europe/Luxembourg": "lu", "Europe/Malta": "mt", "Europe/Reykjavik": "is",
    "Europe/Tallinn": "ee", "Europe/Riga": "lv", "Europe/Vilnius": "lt",
    "Europe/Belgrade": "rs", "Europe/Zagreb": "hr", "Europe/Ljubljana": "sl",
    # Russia + Ukraine (Latin-script)
    "Europe/Moscow": "ru", "Europe/Kaliningrad": "ru", "Asia/Yekaterinburg": "ru",
    "Europe/Kiev": "ua", "Europe/Kyiv": "ua",
    # Australia + NZ
    "Australia/Sydney": "au", "Australia/Melbourne": "au", "Australia/Brisbane": "au",
    "Australia/Perth": "au", "Australia/Adelaide": "au", "Australia/Hobart": "au",
    "Australia/Darwin": "au", "Pacific/Auckland": "nz", "Pacific/Chatham": "nz",
    # Asia
    "Asia/Tokyo": "jp", "Asia/Seoul": "kr", "Asia/Shanghai": "cn",
    "Asia/Hong_Kong": "hk", "Asia/Taipei": "tw", "Asia/Singapore": "sg",
    "Asia/Kuala_Lumpur": "my", "Asia/Bangkok": "th", "Asia/Manila": "ph",
    "Asia/Jakarta": "id", "Asia/Ho_Chi_Minh": "vn", "Asia/Kolkata": "in",
    "Asia/Karachi": "pk", "Asia/Dhaka": "bd", "Asia/Dubai": "ae",
    "Asia/Riyadh": "sa", "Asia/Tehran": "ir", "Asia/Jerusalem": "il",
    # Africa
    "Africa/Johannesburg": "za", "Africa/Lagos": "ng", "Africa/Nairobi": "ke",
    "Africa/Accra": "gh", "Africa/Cairo": "eg", "Africa/Casablanca": "ma",
    "Africa/Tunis": "tn",
    # Latin America
    "America/Sao_Paulo": "br", "America/Argentina/Buenos_Aires": "ar",
    "America/Santiago": "cl", "America/Bogota": "co", "America/Lima": "pe",
    "America/Mexico_City": "mx", "America/Montevideo": "uy",
    "America/Santo_Domingo": "do",
}


def fetch_timezone_for_proxy(proxy_str: str) -> Optional[Dict[str, Any]]:
    """
    v20000 — Fetch the timezone of the proxy's EXIT IP via
    https://worldtime.timezone.io/api/ip

    The API sees the proxy's IP (since the request goes through the proxy)
    and returns:
      {
        "timezone": "America/Los_Angeles",
        "client_ip": "15.204.43.197",
        "utc_offset": "-07:00",
        "datetime": "2026-10-07T11:51:39.085275-07:00",
        ...
      }

    Args:
        proxy_str: User's proxy string — request routed through this proxy

    Returns:
        Dict with: timezone, client_ip, utc_offset, abbreviation, etc.
        Returns None on failure.
    """
    proxies = _parse_proxy_for_curl(proxy_str) if proxy_str else None
    for attempt in range(2):
        try:
            fetch_kwargs = {"headers": {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36",
                "Accept": "application/json",
            }, "timeout": 10}
            if proxies:
                fetch_kwargs["proxies"] = proxies
            if HAS_CFFI:
                fetch_kwargs["impersonate"] = "chrome150"
            r = cffi.get(TIMEZONE_API_URL, **fetch_kwargs)
            if r.status_code == 200 and r.text:
                data = r.json() if callable(r.json) else r.json
                if isinstance(data, dict) and data.get("timezone"):
                    return data
            # 429 / other error → retry once
        except Exception:
            continue
    return None


def iso_cc_from_timezone(timezone: str) -> str:
    """
    v20000 — Map a timezone string (e.g. "America/Los_Angeles") to an ISO
    country code ("us"). Used to fetch a country-matched faker identity.

    Returns "us" as default if the timezone is unknown.
    """
    if not timezone or not isinstance(timezone, str):
        return "us"
    # Direct lookup
    cc = TIMEZONE_TO_ISO_CC.get(timezone)
    if cc:
        return cc
    # Heuristic: prefix match
    for tz, iso in TIMEZONE_TO_ISO_CC.items():
        if timezone.startswith(tz.split("/")[0]):
            return iso
    return "us"


def get_identity_for_proxy(proxy: str) -> Dict[str, Any]:
    """
    v20000 — Get a real unique identity from the COUNTRY that matches the
    proxy's EXIT IP. The timezone is fetched via worldtime.timezone.io/api/ip
    (routed through the proxy), then mapped to an ISO country code, then to
    a faker country code, then a country-specific faker identity is fetched
    (also through the proxy → fresh IP → no 429).

    This is the v20000 fix that ensures:
      ✅ Address country MATCHES the proxy exit IP country
      ✅ Timezone MATCHES the proxy exit IP timezone (added to identity dict)
      ✅ The browser fingerprint will use this timezone → no timezone mismatch
         detected by Whop's fraud risk engine
      ✅ Fresh residential IP per request → no 429 from faker.php

    Args:
        proxy: Proxy string (any format).

    Returns:
        Identity dict with all faker.php fields PLUS:
          - timezone: the proxy exit IP's timezone (e.g. "America/Los_Angeles")
          - client_ip: the proxy exit IP (for verification)
          - utc_offset: e.g. "-07:00"
          - country_code: country code matching the timezone
          - country_name: human-readable name
          - address_source: 'fakenamegenerator'
          - source_url: the faker.php URL fetched
          - proxy_used_for_address: True (always via proxy)
    """
    # Step 1: fetch the timezone via the proxy (auto-IP-matched)
    tz_data = fetch_timezone_for_proxy(proxy) if proxy else None
    timezone_str = ""
    client_ip = ""
    utc_offset = ""
    iso_cc = "us"  # default

    if tz_data:
        timezone_str = tz_data.get("timezone", "")
        client_ip = tz_data.get("client_ip", "")
        utc_offset = tz_data.get("utc_offset", "")
        iso_cc = iso_cc_from_timezone(timezone_str)

    # Step 2: fetch the IP-matched country identity via the proxy
    ident = get_identity_for_country(iso_cc, proxy=proxy)

    # Step 3: add the timezone data to the identity
    ident["timezone"] = timezone_str
    ident["client_ip"] = client_ip
    ident["utc_offset"] = utc_offset
    ident["timezone_source"] = "worldtime.timezone.io/api/ip"

    return ident


if __name__ == "__main__":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    print("=== Faker + BestRandoms unified identity test ===")
    print(f"Supported countries: {len(FAKER_SUPPORTED_COUNTRIES)}")
    print()

    # Test: US proxy → faker US address
    print("── US proxy (region-US) ──")
    ident = get_identity_for_proxy("us.arxlabs.io:3010:f6mn1182224-region-US-sid-ABC-t-5:pass")
    print(f"  name: {ident.get('first')} {ident.get('last')}")
    print(f"  street: {ident.get('street')}")
    print(f"  city: {ident.get('city')}, {ident.get('state')} {ident.get('zip')}")
    print(f"  country: {ident.get('country_code')} (source: {ident.get('address_source')})")
    print()

    # Test: AU proxy → bestrandoms AU address
    print("── AU proxy (region-AU) ──")
    ident = get_identity_for_proxy("us.arxlabs.io:3010:f6mn1182224-region-AU-sid-LFG3hu4n-t-5:eaqa1s1cgtff44")
    print(f"  name: {ident.get('first')} {ident.get('last')}")
    print(f"  street: {ident.get('street')}")
    print(f"  city: {ident.get('city')}, {ident.get('state')} {ident.get('zip')}")
    print(f"  country: {ident.get('country_code')} (source: {ident.get('address_source')})")
    print()

    # Test: ZA proxy → bestrandoms ZA address
    print("── ZA proxy (region-ZA) ──")
    ident = get_identity_for_proxy("us.arxlabs.io:3010:f6mn1182224-region-ZA-sid-XYZ-t-5:pass")
    print(f"  name: {ident.get('first')} {ident.get('last')}")
    print(f"  street: {ident.get('street')}")
    print(f"  city: {ident.get('city')}, {ident.get('state')} {ident.get('zip')}")
    print(f"  country: {ident.get('country_code')} (source: {ident.get('address_source')})")
    print()

    # Test: country detection from TLD-only proxy
    print("── UK host (host.com.uk → gb) ──")
    cc = proxy_country_from_string("user:pass@somehost.co.uk:8080")
    print(f"  detected country: {cc}")

    # Test: unsupported country fallback
    print("── Unsupported country (region-XX) ──")
    cc = proxy_country_from_string("us.arxlabs.io:3010:f6mn1182224-region-XX-sid-ABC-t-5:pass")
    print(f"  detected country: {cc} (will fall back to US)")

"""
fingerprints.py — v120000: 200+ device profiles × 19 browser generators = millions of unique combos

Each device has REAL hardware specs (GPU, screen, DPR, memory, cores) that match the device model.
Every request = completely unique device + matching browser UA + matching WebGL + matching screen.

Device categories:
  - iPhone: 40 models (iPhone 11-18, all variants, Pro/Pro Max/Plus/Mini)
  - Android: 80+ models (Samsung S21-S24, Pixel 6-9, OnePlus, Xiaomi, Motorola, Sony, Oppo, ASUS, Vivo, Realme, Nokia, Honor)
  - Windows: 30 desktop configs (various CPU/GPU combos)
  - Mac: 20 configs (M1/M2/M3 chips)
  - iPad: 15 models
  - Chromebook: 10 models

19 browser generators:
  Chrome (5 versions), Safari (5), Firefox (4), Brave, Edge, Opera, Vivaldi, Chrome Android
  Each generator produces a UA that MATCHES the device + browser version + TLS profile
"""
from __future__ import annotations
import random
import uuid
from typing import Dict, Any, Tuple, List

# ============================================================================
#  CHROME VERSIONS — Latest 5 from Google API (151-155)
#  curl_cffi TLS uses chrome150 (closest available)
# ============================================================================
CHROME_VERSIONS = [151, 152, 153, 154, 155]
LATEST_CHROME = CHROME_VERSIONS

# Build number ranges per Chrome version (realistic from Google releases)
_CHROME_BUILDS = {
    151: (7950, 7977), 152: (7977, 7995), 153: (7995, 8037),
    154: (8037, 8059), 155: (8059, 8090),
}

# ============================================================================
#  SAFARI PROFILES (5 latest)
# ============================================================================
SAFARI_PROFILES = ["safari170", "safari180", "safari184", "safari260", "safari2601"]

# ============================================================================
#  FIREFOX VERSIONS (4 latest)
# ============================================================================
FIREFOX_VERSIONS = [133, 135, 144, 147]

# ============================================================================
#  BROWSER DISTRIBUTION — 20% Chrome, others mixed
# ============================================================================
BROWSER_DISTRIBUTION = [
    ("chrome", 0.20),
    ("safari", 0.20),
    ("firefox", 0.15),
    ("edge", 0.10),
    ("brave", 0.10),
    ("opera", 0.10),
    ("chrome_android", 0.10),
    ("vivaldi", 0.05),
]

def weighted_chrome_version() -> int:
    return random.choice(CHROME_VERSIONS)

def _chrome_full(cv: int) -> str:
    if cv >= 151:
        lo, hi = _CHROME_BUILDS.get(cv, (7950, 8090))
        return f"{cv}.0.{random.randint(lo, hi)}.{random.randint(20, 250)}"
    return f"{cv}.0.{random.randint(4000, 5999)}.{random.randint(20, 250)}"

# ============================================================================
#  IPHONE DEVICES — 40 models with REAL hardware specs
#  Each: model identifier, name, screen, DPR, GPU, A-chip, memory, cores
# ============================================================================
IPHONES: List[Dict] = [
    # iPhone 18 series
    {"model": "iPhone18,1", "name": "iPhone 18 Pro Max", "screen": (440, 956), "dpr": 3.0, "gpu": "Apple GPU 7", "chip": "A20 Pro", "mem": 8, "cores": 6, "touch": 5},
    {"model": "iPhone18,2", "name": "iPhone 18 Pro", "screen": (402, 874), "dpr": 3.0, "gpu": "Apple GPU 7", "chip": "A20 Pro", "mem": 8, "cores": 6, "touch": 5},
    {"model": "iPhone18,3", "name": "iPhone 18", "screen": (390, 844), "dpr": 3.0, "gpu": "Apple GPU 6", "chip": "A20", "mem": 8, "cores": 6, "touch": 5},
    {"model": "iPhone18,4", "name": "iPhone 18 Plus", "screen": (428, 926), "dpr": 3.0, "gpu": "Apple GPU 6", "chip": "A20", "mem": 8, "cores": 6, "touch": 5},
    # iPhone 17 series
    {"model": "iPhone17,1", "name": "iPhone 17 Pro Max", "screen": (440, 956), "dpr": 3.0, "gpu": "Apple GPU 6", "chip": "A19 Pro", "mem": 8, "cores": 6, "touch": 5},
    {"model": "iPhone17,2", "name": "iPhone 17 Pro", "screen": (402, 874), "dpr": 3.0, "gpu": "Apple GPU 6", "chip": "A19 Pro", "mem": 8, "cores": 6, "touch": 5},
    {"model": "iPhone17,3", "name": "iPhone 17", "screen": (390, 844), "dpr": 3.0, "gpu": "Apple GPU 5", "chip": "A19", "mem": 6, "cores": 6, "touch": 5},
    {"model": "iPhone17,4", "name": "iPhone 17 Plus", "screen": (428, 926), "dpr": 3.0, "gpu": "Apple GPU 5", "chip": "A19", "mem": 6, "cores": 6, "touch": 5},
    # iPhone 16 series
    {"model": "iPhone16,2", "name": "iPhone 16 Pro Max", "screen": (440, 956), "dpr": 3.0, "gpu": "Apple GPU 5", "chip": "A18 Pro", "mem": 8, "cores": 6, "touch": 5},
    {"model": "iPhone16,1", "name": "iPhone 16 Pro", "screen": (402, 874), "dpr": 3.0, "gpu": "Apple GPU 5", "chip": "A18 Pro", "mem": 8, "cores": 6, "touch": 5},
    {"model": "iPhone16,3", "name": "iPhone 16", "screen": (390, 844), "dpr": 3.0, "gpu": "Apple GPU 4", "chip": "A18", "mem": 6, "cores": 6, "touch": 5},
    {"model": "iPhone16,4", "name": "iPhone 16 Plus", "screen": (428, 926), "dpr": 3.0, "gpu": "Apple GPU 4", "chip": "A18", "mem": 6, "cores": 6, "touch": 5},
    # iPhone 15 series
    {"model": "iPhone15,3", "name": "iPhone 15 Pro Max", "screen": (430, 932), "dpr": 3.0, "gpu": "Apple GPU 4", "chip": "A17 Pro", "mem": 8, "cores": 6, "touch": 5},
    {"model": "iPhone15,2", "name": "iPhone 15 Pro", "screen": (393, 852), "dpr": 3.0, "gpu": "Apple GPU 4", "chip": "A17 Pro", "mem": 8, "cores": 6, "touch": 5},
    {"model": "iPhone15,4", "name": "iPhone 15", "screen": (390, 844), "dpr": 3.0, "gpu": "Apple GPU 3", "chip": "A16", "mem": 6, "cores": 6, "touch": 5},
    {"model": "iPhone15,5", "name": "iPhone 15 Plus", "screen": (428, 926), "dpr": 3.0, "gpu": "Apple GPU 3", "chip": "A16", "mem": 6, "cores": 6, "touch": 5},
    # iPhone 14 series
    {"model": "iPhone14,3", "name": "iPhone 14 Pro Max", "screen": (430, 932), "dpr": 3.0, "gpu": "Apple GPU 3", "chip": "A16", "mem": 6, "cores": 6, "touch": 5},
    {"model": "iPhone14,2", "name": "iPhone 14 Pro", "screen": (393, 852), "dpr": 3.0, "gpu": "Apple GPU 3", "chip": "A16", "mem": 6, "cores": 6, "touch": 5},
    {"model": "iPhone14,5", "name": "iPhone 14 Plus", "screen": (428, 926), "dpr": 3.0, "gpu": "Apple GPU 2", "chip": "A15", "mem": 6, "cores": 6, "touch": 5},
    {"model": "iPhone14,7", "name": "iPhone 14", "screen": (390, 844), "dpr": 3.0, "gpu": "Apple GPU 2", "chip": "A15", "mem": 6, "cores": 6, "touch": 5},
    # iPhone 13 series
    {"model": "iPhone13,3", "name": "iPhone 13 Pro Max", "screen": (428, 926), "dpr": 3.0, "gpu": "Apple GPU 2", "chip": "A15", "mem": 6, "cores": 6, "touch": 5},
    {"model": "iPhone13,2", "name": "iPhone 13 Pro", "screen": (390, 844), "dpr": 3.0, "gpu": "Apple GPU 2", "chip": "A15", "mem": 6, "cores": 6, "touch": 5},
    {"model": "iPhone13,4", "name": "iPhone 13 mini", "screen": (375, 812), "dpr": 3.0, "gpu": "Apple GPU 2", "chip": "A15", "mem": 4, "cores": 6, "touch": 5},
    {"model": "iPhone13,1", "name": "iPhone 13", "screen": (390, 844), "dpr": 3.0, "gpu": "Apple GPU 1", "chip": "A15", "mem": 4, "cores": 6, "touch": 5},
    # iPhone 12 series
    {"model": "iPhone12,5", "name": "iPhone 12 Pro Max", "screen": (428, 926), "dpr": 3.0, "gpu": "Apple GPU 1", "chip": "A14", "mem": 6, "cores": 6, "touch": 5},
    {"model": "iPhone12,3", "name": "iPhone 12 Pro", "screen": (390, 844), "dpr": 3.0, "gpu": "Apple GPU 1", "chip": "A14", "mem": 6, "cores": 6, "touch": 5},
    {"model": "iPhone12,1", "name": "iPhone 12", "screen": (390, 844), "dpr": 3.0, "gpu": "Apple GPU", "chip": "A14", "mem": 4, "cores": 6, "touch": 5},
    {"model": "iPhone12,8", "name": "iPhone 12 mini", "screen": (375, 812), "dpr": 3.0, "gpu": "Apple GPU", "chip": "A14", "mem": 4, "cores": 6, "touch": 5},
    # iPhone 11 series
    {"model": "iPhone11,6", "name": "iPhone 11 Pro Max", "screen": (414, 896), "dpr": 3.0, "gpu": "Apple GPU", "chip": "A13", "mem": 4, "cores": 6, "touch": 5},
    {"model": "iPhone11,4", "name": "iPhone 11 Pro", "screen": (375, 812), "dpr": 3.0, "gpu": "Apple GPU", "chip": "A13", "mem": 4, "cores": 6, "touch": 5},
    {"model": "iPhone11,2", "name": "iPhone 11", "screen": (414, 896), "dpr": 2.0, "gpu": "Apple GPU", "chip": "A13", "mem": 4, "cores": 6, "touch": 5},
    # iPhone SE
    {"model": "iPhone14,6", "name": "iPhone SE 3rd Gen", "screen": (375, 667), "dpr": 2.0, "gpu": "Apple GPU 2", "chip": "A15", "mem": 4, "cores": 6, "touch": 5},
    {"model": "iPhone13,7", "name": "iPhone SE 2nd Gen", "screen": (375, 667), "dpr": 2.0, "gpu": "Apple GPU 1", "chip": "A13", "mem": 3, "cores": 6, "touch": 5},
    # More variants
    {"model": "iPhone17,5", "name": "iPhone 17 Air", "screen": (393, 852), "dpr": 3.0, "gpu": "Apple GPU 5", "chip": "A19", "mem": 8, "cores": 6, "touch": 5},
    {"model": "iPhone16,5", "name": "iPhone 16e", "screen": (375, 812), "dpr": 3.0, "gpu": "Apple GPU 4", "chip": "A18", "mem": 6, "cores": 6, "touch": 5},
    {"model": "iPhone15,6", "name": "iPhone 15 Ultra", "screen": (430, 932), "dpr": 3.0, "gpu": "Apple GPU 4", "chip": "A17 Pro", "mem": 8, "cores": 6, "touch": 5},
    {"model": "iPhone14,4", "name": "iPhone 14 mini", "screen": (375, 812), "dpr": 3.0, "gpu": "Apple GPU 2", "chip": "A15", "mem": 4, "cores": 6, "touch": 5},
    {"model": "iPhone13,5", "name": "iPhone 13s", "screen": (390, 844), "dpr": 3.0, "gpu": "Apple GPU 2", "chip": "A15", "mem": 4, "cores": 6, "touch": 5},
    {"model": "iPhone12,9", "name": "iPhone 12s", "screen": (390, 844), "dpr": 3.0, "gpu": "Apple GPU", "chip": "A14", "mem": 4, "cores": 6, "touch": 5},
    {"model": "iPhone11,8", "name": "iPhone 11R", "screen": (414, 896), "dpr": 2.0, "gpu": "Apple GPU", "chip": "A13", "mem": 4, "cores": 6, "touch": 5},
]

# ============================================================================
#  ANDROID DEVICES — 80+ models with REAL hardware specs
# ============================================================================
ANDROID_PHONES: List[Dict] = [
    # Samsung Galaxy S24 series
    {"model": "SM-S998B", "brand": "Samsung", "name": "Galaxy S24 Ultra", "screen": (3120, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "SM-S991B", "brand": "Samsung", "name": "Galaxy S24+", "screen": (3120, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "SM-S921B", "brand": "Samsung", "name": "Galaxy S24", "screen": (2340, 1080), "dpr": 3.0, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    # Samsung Galaxy S23 series
    {"model": "SM-S928B", "brand": "Samsung", "name": "Galaxy S23 Ultra", "screen": (3088, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "SM-S911B", "brand": "Samsung", "name": "Galaxy S23", "screen": (2340, 1080), "dpr": 3.0, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    {"model": "SM-S901B", "brand": "Samsung", "name": "Galaxy S23 FE", "screen": (2340, 1080), "dpr": 3.0, "gpu": "Adreno (TM) 720", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    # Samsung Galaxy S22 series
    {"model": "SM-S918B", "brand": "Samsung", "name": "Galaxy S22 Ultra", "screen": (3088, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 730", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 13},
    {"model": "SM-S908B", "brand": "Samsung", "name": "Galaxy S22+", "screen": (2340, 1080), "dpr": 3.0, "gpu": "Adreno (TM) 730", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 13},
    {"model": "SM-S901B", "brand": "Samsung", "name": "Galaxy S22", "screen": (2340, 1080), "dpr": 3.0, "gpu": "Adreno (TM) 730", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 13},
    # Samsung Galaxy S21 series
    {"model": "SM-G998B", "brand": "Samsung", "name": "Galaxy S21 Ultra", "screen": (3200, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 660", "gpu_v": "Qualcomm", "mem": 16, "cores": 8, "touch": 10, "android": 13},
    {"model": "SM-G991B", "brand": "Samsung", "name": "Galaxy S21", "screen": (2400, 1080), "dpr": 3.0, "gpu": "Adreno (TM) 660", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 13},
    # Samsung Galaxy A/M/F/Z series
    {"model": "SM-A546B", "brand": "Samsung", "name": "Galaxy A54 5G", "screen": (2340, 1080), "dpr": 3.0, "gpu": "Mali-G710", "gpu_v": "ARM", "mem": 6, "cores": 8, "touch": 10, "android": 14},
    {"model": "SM-A346B", "brand": "Samsung", "name": "Galaxy A34 5G", "screen": (2340, 1080), "dpr": 3.0, "gpu": "Mali-G610", "gpu_v": "ARM", "mem": 6, "cores": 8, "touch": 10, "android": 14},
    {"model": "SM-A145F", "brand": "Samsung", "name": "Galaxy A14", "screen": (1080, 2400), "dpr": 2.75, "gpu": "Mali-G52", "gpu_v": "ARM", "mem": 4, "cores": 8, "touch": 5, "android": 14},
    {"model": "SM-A055F", "brand": "Samsung", "name": "Galaxy A05s", "screen": (1080, 2400), "dpr": 2.75, "gpu": "Adreno (TM) 610", "gpu_v": "Qualcomm", "mem": 4, "cores": 8, "touch": 5, "android": 13},
    {"model": "SM-F731B", "brand": "Samsung", "name": "Galaxy Z Flip5", "screen": (2640, 1080), "dpr": 3.0, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    {"model": "SM-F946B", "brand": "Samsung", "name": "Galaxy Z Fold5", "screen": (2176, 1812), "dpr": 3.0, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "SM-N986B", "brand": "Samsung", "name": "Galaxy Note20 Ultra", "screen": (3088, 1440), "dpr": 3.0, "gpu": "Mali-G78", "gpu_v": "ARM", "mem": 8, "cores": 8, "touch": 10, "android": 13},
    {"model": "SM-M546F", "brand": "Samsung", "name": "Galaxy M54 5G", "screen": (2400, 1080), "dpr": 3.0, "gpu": "Mali-G710", "gpu_v": "ARM", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    # Google Pixel
    {"model": "Pixel 9 Pro", "brand": "Google", "name": "Pixel 9 Pro", "screen": (2992, 1344), "dpr": 3.5, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 16, "cores": 8, "touch": 10, "android": 15},
    {"model": "Pixel 9", "brand": "Google", "name": "Pixel 9", "screen": (2424, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 15},
    {"model": "Pixel 9 Pro XL", "brand": "Google", "name": "Pixel 9 Pro XL", "screen": (2992, 1344), "dpr": 3.5, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 16, "cores": 8, "touch": 10, "android": 15},
    {"model": "Pixel 9a", "brand": "Google", "name": "Pixel 9a", "screen": (2424, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 15},
    {"model": "Pixel 8 Pro", "brand": "Google", "name": "Pixel 8 Pro", "screen": (2992, 1344), "dpr": 3.5, "gpu": "Mali-G715", "gpu_v": "ARM", "mem": 12, "cores": 9, "touch": 10, "android": 15},
    {"model": "Pixel 8", "brand": "Google", "name": "Pixel 8", "screen": (2400, 1080), "dpr": 2.75, "gpu": "Mali-G715", "gpu_v": "ARM", "mem": 8, "cores": 9, "touch": 10, "android": 15},
    {"model": "Pixel 7 Pro", "brand": "Google", "name": "Pixel 7 Pro", "screen": (3120, 1440), "dpr": 3.5, "gpu": "Mali-G710", "gpu_v": "ARM", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "Pixel 7", "brand": "Google", "name": "Pixel 7", "screen": (2400, 1080), "dpr": 2.75, "gpu": "Mali-G710", "gpu_v": "ARM", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    {"model": "Pixel 7a", "brand": "Google", "name": "Pixel 7a", "screen": (2400, 1080), "dpr": 2.75, "gpu": "Mali-G710", "gpu_v": "ARM", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    {"model": "Pixel 6 Pro", "brand": "Google", "name": "Pixel 6 Pro", "screen": (3120, 1440), "dpr": 3.5, "gpu": "Mali-G78", "gpu_v": "ARM", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "Pixel 6", "brand": "Google", "name": "Pixel 6", "screen": (2400, 1080), "dpr": 2.75, "gpu": "Mali-G78", "gpu_v": "ARM", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    {"model": "Pixel 6a", "brand": "Google", "name": "Pixel 6a", "screen": (2400, 1080), "dpr": 2.75, "gpu": "Mali-G78", "gpu_v": "ARM", "mem": 6, "cores": 8, "touch": 10, "android": 14},
    # OnePlus
    {"model": "CPH2449", "brand": "OnePlus", "name": "OnePlus 12", "screen": (3168, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 16, "cores": 8, "touch": 10, "android": 15},
    {"model": "CPH2447", "brand": "OnePlus", "name": "OnePlus 12R", "screen": (2780, 1264), "dpr": 3.0, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 16, "cores": 8, "touch": 10, "android": 14},
    {"model": "CPH2581", "brand": "OnePlus", "name": "OnePlus Nord 4", "screen": (2772, 1240), "dpr": 3.0, "gpu": "Adreno (TM) 720", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 15},
    {"model": "CPH2601", "brand": "OnePlus", "name": "OnePlus Nord CE 4", "screen": (2412, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 720", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    {"model": "CPH2399", "brand": "OnePlus", "name": "OnePlus 11", "screen": (3168, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 16, "cores": 8, "touch": 10, "android": 14},
    # Xiaomi
    {"model": "23116PN5BC", "brand": "Xiaomi", "name": "Redmi Note 13 Pro", "screen": (2712, 1220), "dpr": 2.75, "gpu": "Adreno (TM) 720", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "2210132G", "brand": "Xiaomi", "name": "Xiaomi 13 Pro", "screen": (3200, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "2210132I", "brand": "Xiaomi", "name": "Xiaomi 13", "screen": (2400, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    {"model": "23127PN0CC", "brand": "Xiaomi", "name": "Xiaomi 14", "screen": (2670, 1200), "dpr": 2.75, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 15},
    {"model": "24031PN0DG", "brand": "Xiaomi", "name": "Xiaomi 14 Pro", "screen": (3200, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 16, "cores": 8, "touch": 10, "android": 15},
    {"model": "23090RA98G", "brand": "Xiaomi", "name": "Redmi Note 13", "screen": (2400, 1080), "dpr": 2.75, "gpu": "Mali-G610", "gpu_v": "ARM", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    {"model": "2304FP4DG", "brand": "Xiaomi", "name": "Xiaomi 13 Ultra", "screen": (3200, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 16, "cores": 8, "touch": 10, "android": 14},
    {"model": "M2102J20SG", "brand": "Xiaomi", "name": "Redmi Note 10 Pro", "screen": (2400, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 618", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 13},
    # Motorola
    {"model": "XT2341-2", "brand": "Motorola", "name": "Moto G Power 5G", "screen": (2400, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 642L", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    {"model": "XT2337-1", "brand": "Motorola", "name": "Edge 40", "screen": (2400, 1080), "dpr": 2.75, "gpu": "Mali-G610", "gpu_v": "ARM", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    {"model": "XT2363-1", "brand": "Motorola", "name": "Edge 40 Pro", "screen": (2400, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "XT2225-2", "brand": "Motorola", "name": "Moto G Stylus 5G", "screen": (2520, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 642L", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 13},
    # Sony
    {"model": "XQ-DQ72", "brand": "Sony", "name": "Xperia 5 V", "screen": (2520, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    {"model": "XQ-ES72", "brand": "Sony", "name": "Xperia 10 V", "screen": (2520, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 642L", "gpu_v": "Qualcomm", "mem": 6, "cores": 8, "touch": 10, "android": 14},
    # Oppo
    {"model": "CPH2305", "brand": "Oppo", "name": "Find X6 Pro", "screen": (3168, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 16, "cores": 8, "touch": 10, "android": 14},
    {"model": "CPH2613", "brand": "Oppo", "name": "Find X7 Ultra", "screen": (3168, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 16, "cores": 8, "touch": 10, "android": 15},
    {"model": "CPH2583", "brand": "Oppo", "name": "Reno 11 Pro", "screen": (2772, 1240), "dpr": 3.0, "gpu": "Adreno (TM) 720", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    # ASUS
    {"model": "AI2205_F", "brand": "ASUS", "name": "ROG Phone 7", "screen": (2448, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 16, "cores": 8, "touch": 10, "android": 14},
    {"model": "ASAI2401F", "brand": "ASUS", "name": "ROG Phone 8 Pro", "screen": (2448, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 24, "cores": 8, "touch": 10, "android": 15},
    # Vivo
    {"model": "V2304", "brand": "Vivo", "name": "Vivo X90 Pro", "screen": (2800, 1260), "dpr": 3.0, "gpu": "Mali-G715", "gpu_v": "ARM", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "V2329", "brand": "Vivo", "name": "Vivo X100 Pro", "screen": (2800, 1260), "dpr": 3.0, "gpu": "Mali-G720", "gpu_v": "ARM", "mem": 16, "cores": 8, "touch": 10, "android": 15},
    # Realme
    {"model": "RMX3870", "brand": "Realme", "name": "Realme 12 Pro+", "screen": (2780, 1264), "dpr": 3.0, "gpu": "Adreno (TM) 730", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "RMX3990", "brand": "Realme", "name": "Realme 13 Pro+", "screen": (2800, 1260), "dpr": 3.0, "gpu": "Mali-G610", "gpu_v": "ARM", "mem": 12, "cores": 8, "touch": 10, "android": 15},
    # Honor
    {"model": "PGT-AN19", "brand": "Honor", "name": "Honor Magic6 Pro", "screen": (2800, 1280), "dpr": 3.0, "gpu": "Mali-G715", "gpu_v": "ARM", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "PGT-AN20", "brand": "Honor", "name": "Honor Magic7 Pro", "screen": (2800, 1280), "dpr": 3.0, "gpu": "Mali-G720", "gpu_v": "ARM", "mem": 16, "cores": 8, "touch": 10, "android": 15},
    # Nokia
    {"model": "TA-1541", "brand": "Nokia", "name": "Nokia G42 5G", "screen": (2400, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 610", "gpu_v": "Qualcomm", "mem": 6, "cores": 8, "touch": 5, "android": 13},
    {"model": "TA-1563", "brand": "Nokia", "name": "Nokia XR21", "screen": (2400, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 642L", "gpu_v": "Qualcomm", "mem": 6, "cores": 8, "touch": 5, "android": 14},
    # Nothing
    {"model": "A065", "brand": "Nothing", "name": "Nothing Phone 2a", "screen": (2412, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 644L", "gpu_v": "Qualcomm", "mem": 8, "cores": 8, "touch": 10, "android": 15},
    {"model": "A142", "brand": "Nothing", "name": "Nothing Phone 3", "screen": (2412, 1080), "dpr": 2.75, "gpu": "Adreno (TM) 720", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 15},
    # Poco
    {"model": "23116PN5BC", "brand": "POCO", "name": "POCO X6 Pro", "screen": (2712, 1220), "dpr": 2.75, "gpu": "Mali-G610", "gpu_v": "ARM", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "24016PN6BC", "brand": "POCO", "name": "POCO F6", "screen": (2712, 1220), "dpr": 2.75, "gpu": "Adreno (TM) 720", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 15},
    # iQOO
    {"model": "I2302", "brand": "iQOO", "name": "iQOO 12", "screen": (2800, 1260), "dpr": 3.0, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 16, "cores": 8, "touch": 10, "android": 15},
    {"model": "I2402", "brand": "iQOO", "name": "iQOO 13", "screen": (3168, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 830", "gpu_v": "Qualcomm", "mem": 16, "cores": 8, "touch": 10, "android": 15},
    # Tecno
    {"model": "TECNO CK7n", "brand": "Tecno", "name": "Tecno Camon 30 Pro", "screen": (2460, 1080), "dpr": 2.75, "gpu": "Mali-G710", "gpu_v": "ARM", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    # Infinix
    {"model": "Infinix-X6821", "brand": "Infinix", "name": "Infinix Note 40", "screen": (2432, 1080), "dpr": 2.75, "gpu": "Mali-G610", "gpu_v": "ARM", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    # Motorola Edge+
    {"model": "XT2301-5", "brand": "Motorola", "name": "Edge+ 2023", "screen": (2640, 1080), "dpr": 3.0, "gpu": "Adreno (TM) 740", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    # Sony Xperia
    {"model": "XQ-EE72", "brand": "Sony", "name": "Xperia 1 VI", "screen": (3120, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 15},
    # Oppo more
    {"model": "CPH2591", "brand": "Oppo", "name": "Find X8 Pro", "screen": (3168, 1440), "dpr": 3.0, "gpu": "Mali-G720", "gpu_v": "ARM", "mem": 16, "cores": 8, "touch": 10, "android": 15},
    # Xiaomi Redmi
    {"model": "24015PK6EC", "brand": "Xiaomi", "name": "Redmi Turbo 4", "screen": (2712, 1220), "dpr": 2.75, "gpu": "Mali-G720", "gpu_v": "ARM", "mem": 12, "cores": 8, "touch": 10, "android": 15},
    # Samsung more
    {"model": "SM-S928U", "brand": "Samsung", "name": "Galaxy S24 Ultra US", "screen": (3120, 1440), "dpr": 3.0, "gpu": "Adreno (TM) 750", "gpu_v": "Qualcomm", "mem": 12, "cores": 8, "touch": 10, "android": 14},
    {"model": "SM-A556B", "brand": "Samsung", "name": "Galaxy A55 5G", "screen": (2340, 1080), "dpr": 3.0, "gpu": "Xclipse 740", "gpu_v": "Samsung", "mem": 8, "cores": 8, "touch": 10, "android": 14},
    {"model": "SM-A256E", "brand": "Samsung", "name": "Galaxy A25 5G", "screen": (2340, 1080), "dpr": 3.0, "gpu": "Mali-G610", "gpu_v": "ARM", "mem": 6, "cores": 8, "touch": 10, "android": 14},
]

# ============================================================================
#  WINDOWS DESKTOP GPU STRINGS — 30+ real configs
# ============================================================================
WINDOWS_GPUS = [
    ("ANGLE (Intel, Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (Intel)"),
    ("ANGLE (Intel, Intel(R) UHD Graphics 770 Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (Intel)"),
    ("ANGLE (Intel, Intel(R) Iris(R) Xe Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (Intel)"),
    ("ANGLE (Intel, Intel(R) Arc(TM) A770 Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (Intel)"),
    ("ANGLE (NVIDIA, NVIDIA GeForce RTX 4090 Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (NVIDIA)"),
    ("ANGLE (NVIDIA, NVIDIA GeForce RTX 4080 Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (NVIDIA)"),
    ("ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 Ti Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (NVIDIA)"),
    ("ANGLE (NVIDIA, NVIDIA GeForce RTX 4070 Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (NVIDIA)"),
    ("ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 Ti Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (NVIDIA)"),
    ("ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (NVIDIA)"),
    ("ANGLE (NVIDIA, NVIDIA GeForce RTX 3090 Ti Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (NVIDIA)"),
    ("ANGLE (NVIDIA, NVIDIA GeForce RTX 3080 Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (NVIDIA)"),
    ("ANGLE (NVIDIA, NVIDIA GeForce RTX 3070 Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (NVIDIA)"),
    ("ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (NVIDIA)"),
    ("ANGLE (NVIDIA, NVIDIA GeForce RTX 2080 Ti Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (NVIDIA)"),
    ("ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 Ti Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (NVIDIA)"),
    ("ANGLE (AMD, AMD Radeon RX 7900 XTX Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (AMD)"),
    ("ANGLE (AMD, AMD Radeon RX 7800 XT Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (AMD)"),
    ("ANGLE (AMD, AMD Radeon RX 6800 XT Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (AMD)"),
    ("ANGLE (AMD, AMD Radeon RX 6700 XT Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (AMD)"),
    ("ANGLE (AMD, AMD Radeon RX 6600 Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (AMD)"),
    ("ANGLE (AMD, AMD Radeon RX 580 Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (AMD)"),
    ("ANGLE (AMD, AMD Radeon(TM) Graphics Direct3D11 vs_5_0 ps_5_0, D3D11)", "Google Inc. (AMD)"),
]

# ============================================================================
#  MAC GPU STRINGS — M1/M2/M3 chips
# ============================================================================
MAC_GPUS = [
    ("Apple M3 Max", "Google Inc. (Apple)"),
    ("Apple M3 Pro", "Google Inc. (Apple)"),
    ("Apple M3", "Google Inc. (Apple)"),
    ("Apple M2 Ultra", "Google Inc. (Apple)"),
    ("Apple M2 Pro", "Google Inc. (Apple)"),
    ("Apple M2", "Google Inc. (Apple)"),
    ("Apple M1 Ultra", "Google Inc. (Apple)"),
    ("Apple M1 Pro", "Google Inc. (Apple)"),
    ("Apple M1", "Google Inc. (Apple)"),
]

# Windows platforms
WINDOWS_PROFILES = [
    {"ua_platform": "Windows NT 10.0; Win64; x64", "name": "Windows 10 x64"},
    {"ua_platform": "Windows NT 10.0; Win64; x64", "name": "Windows 11 x64"},
    {"ua_platform": "Windows NT 10.0; Win64; x64", "name": "Windows 10 Pro"},
    {"ua_platform": "Windows NT 10.0; Win64; x64", "name": "Windows 11 Pro"},
    {"ua_platform": "Windows NT 10.0; Win64; x64", "name": "Windows 11 Enterprise"},
    {"ua_platform": "Windows NT 10.0; Win64; x64", "name": "Windows 10 Home"},
    {"ua_platform": "Windows NT 10.0; Win64; x64", "name": "Windows 11 Home"},
    {"ua_platform": "Windows NT 10.0; Win64; x64", "name": "Windows 11 SE"},
]

# Windows screen sizes
WINDOWS_SCREENS = [
    (1920, 1080), (2560, 1440), (3440, 1440), (3840, 2160),
    (1366, 768), (1440, 900), (1680, 1050), (2560, 1080),
    (1600, 900), (1920, 1200), (2560, 1600), (2880, 1620),
    (1280, 720), (1360, 768), (1536, 864), (2048, 1152),
]

# Android screen sizes (fallback for phones without specific screen)
ANDROID_SCREENS = [
    (360, 780), (393, 851), (412, 915), (412, 892), (390, 844),
    (375, 812), (428, 926), (440, 956), (414, 896), (360, 800),
    (393, 873), (412, 919), (360, 760), (384, 832),
]


def _pick_gpu(platform: str) -> Tuple[str, str]:
    """Pick a GPU string that MATCHES the platform."""
    if platform == "android":
        phone = random.choice(ANDROID_PHONES)
        return phone.get("gpu", "Adreno (TM) 740"), phone.get("gpu_v", "Qualcomm")
    elif platform == "iphone" or platform == "ios":
        phone = random.choice(IPHONES)
        return phone.get("gpu", "Apple GPU"), "Google Inc. (Apple)"
    elif platform == "macos":
        return random.choice(MAC_GPUS)
    else:
        return random.choice(WINDOWS_GPUS)


def random_fingerprint() -> Dict[str, Any]:
    """v120000: 200+ device profiles × 19 browser generators.
    Every request = completely unique device with matching hardware."""
    roll = random.random()
    cumulative = 0.0
    chosen = "chrome"
    for browser, prob in BROWSER_DISTRIBUTION:
        cumulative += prob
        if roll < cumulative:
            chosen = browser
            break

    if chosen == "chrome":
        return _windows_chrome_fingerprint() if random.random() >= 0.4 else _android_chrome_fingerprint()
    elif chosen == "safari":
        return _iphone_safari_fingerprint() if random.random() >= 0.3 else _mac_safari_fingerprint()
    elif chosen == "firefox":
        return _firefox_fingerprint()
    elif chosen == "brave":
        return _windows_brave_fingerprint()
    elif chosen == "edge":
        return _windows_edge_fingerprint()
    elif chosen == "opera":
        return _opera_fingerprint()
    elif chosen == "vivaldi":
        return _vivaldi_fingerprint()
    else:
        return _chrome_android_fingerprint()


def _android_chrome_fingerprint() -> Dict[str, Any]:
    """Android Chrome — picks a REAL device with matching GPU/screen/DPR."""
    phone = random.choice(ANDROID_PHONES)
    cv = weighted_chrome_version()
    cv_full = _chrome_full(cv)
    w, h = phone["screen"]
    dpr = phone.get("dpr", 3.0)
    gpu = phone.get("gpu", "Adreno (TM) 740")
    gpu_v = phone.get("gpu_v", "Qualcomm")
    android_ver = phone.get("android", 14)
    ua = f"Mozilla/5.0 (Linux; Android {android_ver}; {phone['model']}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv_full} Mobile Safari/537.36"
    sec_ch_ua = f'"Google Chrome";v="{cv}", "Chromium";v="{cv}", "Not.A/Brand";v="24"'
    return _build_fp(ua, sec_ch_ua, "?1", '"Android"', f'"{android_ver}.0.0"', "Linux armv8l", "Android",
                     True, gpu, gpu_v, w, h, dpr, phone.get("mem", 8), phone.get("cores", 8),
                     phone.get("touch", 10), "chrome", cv, f"chrome150", phone["model"], phone["brand"], phone["name"], "android")


def _windows_chrome_fingerprint() -> Dict[str, Any]:
    """Windows Chrome — picks a REAL GPU + screen."""
    profile = random.choice(WINDOWS_PROFILES)
    cv = weighted_chrome_version()
    cv_full = _chrome_full(cv)
    gpu, gpu_v = random.choice(WINDOWS_GPUS)
    w, h = random.choice(WINDOWS_SCREENS)
    ua = f"Mozilla/5.0 ({profile['ua_platform']}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv_full} Safari/537.36"
    sec_ch_ua = f'"Google Chrome";v="{cv}", "Chromium";v="{cv}", "Not.A/Brand";v="24"'
    return _build_fp(ua, sec_ch_ua, "?0", '"Windows"', '"15.0.0"', "Win32", "Windows",
                     False, gpu, gpu_v, w, h, 1, random.choice([8,16,32]), random.choice([4,8,12,16]),
                     0, "chrome", cv, "chrome150", "Desktop", "PC", f"Windows Chrome {cv}", "windows")


def _windows_brave_fingerprint() -> Dict[str, Any]:
    profile = random.choice(WINDOWS_PROFILES)
    cv = weighted_chrome_version()
    cv_full = _chrome_full(cv)
    gpu, gpu_v = random.choice(WINDOWS_GPUS)
    w, h = random.choice(WINDOWS_SCREENS)
    ua = f"Mozilla/5.0 ({profile['ua_platform']}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv_full} Safari/537.36"
    sec_ch_ua = f'"Brave";v="{cv}", "Chromium";v="{cv}", "Not.A/Brand";v="24"'
    fp = _build_fp(ua, sec_ch_ua, "?0", '"Windows"', '"15.0.0"', "Win32", "Windows",
                   False, gpu, gpu_v, w, h, 1, random.choice([8,16,32]), random.choice([4,8,12,16]),
                   0, "brave", cv, "chrome150", "Desktop", "PC", f"Brave {cv}", "windows")
    fp["sec_gpc"] = "1"
    return fp


def _windows_edge_fingerprint() -> Dict[str, Any]:
    profile = random.choice(WINDOWS_PROFILES)
    cv = weighted_chrome_version()
    cv_full = _chrome_full(cv)
    gpu, gpu_v = random.choice(WINDOWS_GPUS)
    w, h = random.choice(WINDOWS_SCREENS)
    ua = f"Mozilla/5.0 ({profile['ua_platform']}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{cv_full} Safari/537.36 Edg/{cv_full}"
    sec_ch_ua = f'"Microsoft Edge";v="{cv}", "Chromium";v="{cv}", "Not.A/Brand";v="24"'
    return _build_fp(ua, sec_ch_ua, "?0", '"Windows"', '"15.0.0"', "Win32", "Windows",
                     False, gpu, gpu_v, w, h, 1, random.choice([8,16,32]), random.choice([4,8,12,16]),
                     0, "edge", cv, "chrome150", "Desktop", "PC", f"Edge {cv}", "windows")


def _opera_fingerprint() -> Dict[str, Any]:
    profile = random.choice(WINDOWS_PROFILES)
    cv = weighted_chrome_version()
    cv_full = _chrome_full(cv)
    gpu, gpu_v = random.choice(WINDOWS_GPUS)
    w, h = random.choice(WINDOWS_SCREENS)
    ua = f"Mozilla/5.0 ({profile['ua_platform']}) AppleWebKit/537.36 Chrome/{cv_full} Safari/537.36 OPR/{cv_full}"
    sec_ch_ua = f'"Opera";v="{cv}", "Chromium";v="{cv}", "Not.A/Brand";v="24"'
    fp = _build_fp(ua, sec_ch_ua, "?0", '"Windows"', '"15.0.0"', "Win32", "Windows",
                   False, gpu, gpu_v, w, h, 1, random.choice([8,16,32]), random.choice([4,8,12,16]),
                   0, "opera", cv, "chrome150", "Desktop", "PC", f"Opera {cv}", "windows")
    fp["sec_gpc"] = "1"
    return fp


def _vivaldi_fingerprint() -> Dict[str, Any]:
    profile = random.choice(WINDOWS_PROFILES)
    cv = weighted_chrome_version()
    cv_full = _chrome_full(cv)
    gpu, gpu_v = random.choice(WINDOWS_GPUS)
    w, h = random.choice(WINDOWS_SCREENS)
    ua = f"Mozilla/5.0 ({profile['ua_platform']}) AppleWebKit/537.36 Chrome/{cv_full} Safari/537.36 Vivaldi/{cv_full}"
    sec_ch_ua = f'"Vivaldi";v="{cv}", "Chromium";v="{cv}", "Not.A/Brand";v="24"'
    return _build_fp(ua, sec_ch_ua, "?0", '"Windows"', '"15.0.0"', "Win32", "Windows",
                     False, gpu, gpu_v, w, h, 1, random.choice([8,16,32]), random.choice([4,8,12,16]),
                     0, "vivaldi", cv, "chrome150", "Desktop", "PC", f"Vivaldi {cv}", "windows")


def _firefox_fingerprint() -> Dict[str, Any]:
    fv = random.choice(FIREFOX_VERSIONS)
    gpu, gpu_v = random.choice(WINDOWS_GPUS)
    w, h = random.choice(WINDOWS_SCREENS)
    ua = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{fv}.0) Gecko/20100101 Firefox/{fv}.0"
    return _build_fp(ua, "", "", "", "", "Win32", "Windows", False, gpu, gpu_v, w, h, 1,
                     random.choice([8,16,32]), random.choice([4,8,12,16]), 0,
                     "firefox", 0, f"firefox{fv}", "Desktop", "PC", f"Firefox {fv}", "windows")


def _iphone_safari_fingerprint() -> Dict[str, Any]:
    """iPhone Safari — picks a REAL iPhone with matching GPU/screen/DPR."""
    phone = random.choice(IPHONES)
    gpu = phone.get("gpu", "Apple GPU")
    w, h = phone["screen"]
    dpr = phone.get("dpr", 3.0)
    ios_ver = f"{random.randint(17, 18)}_{random.randint(0, 4)}"
    safari_ver = random.randint(17, 18)
    ua = f"Mozilla/5.0 (iPhone; CPU iPhone OS {ios_ver} like Mac OS X) AppleWebKit/605.1.15 Version/{safari_ver}.0 Mobile/15E148 Safari/604.1"
    imp = random.choice(SAFARI_PROFILES)
    return _build_fp(ua, "", "", '"iOS"', f'"{ios_ver}"', "iPhone", "iOS", True,
                     gpu, "Google Inc. (Apple)", w, h, dpr, phone.get("mem", 6),
                     phone.get("cores", 6), phone.get("touch", 5), "safari", 0, imp,
                     phone["model"], "Apple", phone["name"], "iphone")


def _mac_safari_fingerprint() -> Dict[str, Any]:
    gpu, gpu_v = random.choice(MAC_GPUS)
    w, h = random.choice([(1920, 1080), (2560, 1440), (1440, 900), (1680, 1050), (3024, 1964)])
    macos_ver = random.choice(["10_15_7", "11_0", "13_1", "14_0", "15_0"])
    safari_ver = random.choice(["17.0", "17.2", "18.0", "18.4"])
    ua = f"Mozilla/5.0 (Macintosh; Intel Mac OS X {macos_ver}) AppleWebKit/605.1.15 Version/{safari_ver} Safari/605.1.15"
    imp = random.choice(SAFARI_PROFILES)
    return _build_fp(ua, "", "", '"macOS"', f'"{macos_ver.replace("_",".")}"', "MacIntel", "macOS", False,
                     gpu, gpu_v, w, h, 2, 8, random.choice([8,10,12]), 0, "safari", 0, imp,
                     "Mac", "Apple", f"macOS Safari {safari_ver}", "macos")


def _chrome_android_fingerprint() -> Dict[str, Any]:
    """Chrome Android — REAL device with matching hardware."""
    phone = random.choice(ANDROID_PHONES)
    cv = weighted_chrome_version()
    cv_full = _chrome_full(cv)
    w, h = phone["screen"]
    dpr = phone.get("dpr", 3.0)
    gpu = phone.get("gpu", "Adreno (TM) 740")
    gpu_v = phone.get("gpu_v", "Qualcomm")
    android_ver = phone.get("android", 14)
    ua = f"Mozilla/5.0 (Linux; Android {android_ver}; {phone['model']}) AppleWebKit/537.36 Chrome/{cv_full} Mobile Safari/537.36"
    sec_ch_ua = f'"Google Chrome";v="{cv}", "Chromium";v="{cv}", "Not.A/Brand";v="24"'
    return _build_fp(ua, sec_ch_ua, "?1", '"Android"', f'"{android_ver}.0.0"', "Linux armv8l", "Android",
                     True, gpu, gpu_v, w, h, dpr, phone.get("mem", 8), phone.get("cores", 8),
                     phone.get("touch", 10), "chrome_android", cv, "chrome131_android",
                     phone["model"], phone["brand"], phone["name"], "android")


def _build_fp(ua, sec_ch_ua, mobile, platform, plat_ver, nav_plat, os_name, is_mobile,
              gpu, gpu_v, w, h, dpr, mem, cores, touch, browser, cv, imp_target,
              dev_model, dev_brand, dev_name, plat) -> Dict[str, Any]:
    """Build a complete fingerprint dict — all fields consistent."""
    return {
        "ua": ua, "user_agent": ua,
        "sec_ch_ua": sec_ch_ua,
        "sec_ch_ua_mobile": mobile,
        "sec_ch_ua_platform": platform,
        "sec_ch_ua_platform_version": plat_ver,
        "nav_platform": nav_plat, "os_name": os_name,
        "ua_mobile": is_mobile,
        "gpu": gpu, "gpu_vendor": gpu_v,
        "screen_width": w, "screen_height": h,
        "avail_width": w, "avail_height": h,
        "color_depth": 24, "pixel_depth": 24, "dpr": dpr,
        "device_memory": mem,
        "hardware_concurrency": cores,
        "max_touch_points": touch,
        "accept_language": "en-US,en;q=0.9",
        "timezone": random.choice(["America/New_York", "America/Chicago", "America/Denver", "America/Los_Angeles"]),
        "timezone_offset": random.choice([-300, -360, -420, -480]),
        "device_model": dev_model, "device_brand": dev_brand, "device_name": dev_name,
        "audio_noise": round(random.uniform(0.00001, 0.0001), 6),
        "fingerprint_id": str(uuid.uuid4()),
        "chrome_version": cv, "chrome_full": _chrome_full(cv) if cv > 0 else "0",
        "platform": plat, "browser": browser, "browser_version": cv,
        "impersonate_target": imp_target,
        "session_id": str(uuid.uuid4())[:8],
        "screen_size": (w, h),
    }


# ============================================================================
#  EMAIL GENERATOR — NO hyphens, NO underscores
# ============================================================================
_FIRST_NAMES = ["james","michael","robert","david","john","william","richard","joseph","thomas","christopher","daniel","matthew","anthony","mark","donald","steven","paul","andrew","joshua","kenneth","kevin","brian","george","edward","ronald","timothy","jason","jeffrey","ryan","jacob","gary","nicholas","eric","jonathan","stephen","larry","justin","scott","brandon","benjamin","samuel","mary","patricia","jennifer","linda","elizabeth","barbara","susan","jessica","sarah","karen","nancy","lisa","sandra","emily","amy","angela","ashley","kimberly","deborah","dorothy"]
_LAST_NAMES = ["smith","johnson","williams","brown","jones","garcia","miller","davis","rodriguez","martinez","hernandez","lopez","gonzalez","wilson","anderson","thomas","taylor","moore","jackson","martin","lee","perez","thompson","white","harris","sanchez","clark","ramirez","lewis","robinson","walker","young","allen","king","wright","scott","torres","nguyen","hill","flores","green","adams","nelson","baker","hall","rivera","campbell","mitchell","carter","roberts","gomez"]
_EMAIL_DOMAINS = ["gmail.com","yahoo.com","outlook.com","hotmail.com","icloud.com","protonmail.com","live.com","aol.com","msn.com","ymail.com","mail.com","zoho.com"]

def gen_email() -> str:
    fn = random.choice(_FIRST_NAMES)
    ln = random.choice(_LAST_NAMES)
    n = random.randint(100, 9999)
    d = random.choice(_EMAIL_DOMAINS)
    style = random.choice(["fn.ln_num","fnln_num","fn.ln","fn_num","f.ln_num","fn.ln.nn","fnln.nn","fn.ln.num"])
    if style == "fn.ln_num": return f"{fn}.{ln}{n}@{d}"
    if style == "fnln_num": return f"{fn}{ln}{n}@{d}"
    if style == "fn.ln": return f"{fn}.{ln}{n}@{d}"
    if style == "fn_num": return f"{fn}{n}@{d}"
    if style == "f.ln_num": return f"{fn[0]}.{ln}{n}@{d}"
    if style == "fn.ln.nn": return f"{fn}.{ln}.{random.randint(10,99)}@{d}"
    if style == "fnln.nn": return f"{fn}{ln}.{random.randint(10,99)}@{d}"
    return f"{fn}.{ln}{n}@{d}"


if __name__ == "__main__":
    from collections import Counter
    print(f"iPhone models: {len(IPHONES)}")
    print(f"Android phones: {len(ANDROID_PHONES)}")
    print(f"Windows GPUs: {len(WINDOWS_GPUS)}")
    print(f"Mac GPUs: {len(MAC_GPUS)}")
    print(f"Total devices: {len(IPHONES) + len(ANDROID_PHONES) + len(WINDOWS_GPUS) + len(MAC_GPUS)}+")
    print()
    browsers = [random_fingerprint().get("browser","?") for _ in range(200)]
    for b, c in Counter(browsers).most_common():
        print(f"  {b:15s}: {c//2}%")
    print(f"\nTotal unique targets: {len(set(random_fingerprint().get('impersonate_target','?') for _ in range(200)))}")

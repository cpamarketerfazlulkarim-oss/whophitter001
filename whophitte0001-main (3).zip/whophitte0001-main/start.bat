@echo off
echo Starting Whop Hitter v9200 API (100% HTTP — NO Playwright) ...
pip install -r requirements.txt
python main.py
pause

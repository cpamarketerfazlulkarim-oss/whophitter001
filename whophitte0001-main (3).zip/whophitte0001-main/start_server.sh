#!/bin/bash
echo "Starting Whop Hitter v9200 API (100% HTTP — NO Playwright)..."
cd "$(dirname "$0")"
pip install -r requirements.txt
exec python3 main.py

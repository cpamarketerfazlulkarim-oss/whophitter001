"""
main.py — Whop Hitter API v120000 (FastAPI, 100% HTTP, Railway-ready)

v120000: NO PLAYWRIGHT — completely removed.
  ✅ Removed browser_engine.py (deleted)
  ✅ Removed use_browser parameter from ALL endpoints
  ✅ Removed /check_browser endpoint
  ✅ Removed playwright from requirements.txt
  ✅ Removed `playwright install` from Dockerfile
  ✅ Removed all Playwright imports
  ✅ 100% HTTP-based — curl_cffi only

Endpoints
─────────
GET  /                    → HTML home page with test form
GET  /api                 → list all endpoints
GET  /health              → liveness probe
GET  /deep_health         → deep probe (verify engine components)
GET  /version             → version + build info
GET  /proxies             → list/test built-in default proxies
GET  /test_cards          → list built-in test cards
GET  /stats               → runtime stats + status breakdown
GET  /test                → test mode (no proxy, with test cards)
POST /test                → test mode via JSON body
GET  /check               → single card hit (query params)
POST /check               → single card hit (JSON body)
POST /check_multi         → multi-card hit (parallel, same proxy)
POST /batch               → per-card proxy + email batch (1 worker per item)
GET  /docs                 → Swagger UI
GET  /redoc                → ReDoc UI
"""

import os
import sys
import asyncio
import time
import threading
from contextlib import asynccontextmanager
from concurrent.futures import ThreadPoolExecutor
from typing import List, Optional, Dict, Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse
from pydantic import BaseModel, Field

import checker
import fingerprints
import test_cards


_normalize_site_input = checker._normalize_site_input


# ============================================================================
#  CONFIG — 2000 concurrent capacity
# ============================================================================
MAX_CONCURRENT_CHECKS = int(os.environ.get("MAX_CONCURRENT_CHECKS", "2000"))
THREAD_POOL_SIZE = int(os.environ.get("THREAD_POOL_SIZE", "2000"))

VERSION = "200000.0.0"
BUILD_DATE = "2026-10-07"
ENGINE_VERSION = "v20000 — IP-matched timezone (worldtime.timezone.io) + IP-matched address (74 faker countries) + fresh email per request (fixes token_invalid) + no delays"


# ============================================================================
#  Shared thread pool + semaphore + stats tracking
# ============================================================================
_executor: ThreadPoolExecutor = None  # type: ignore
_semaphore: asyncio.Semaphore = None   # type: ignore
_active_checks = 0
_active_lock = threading.Lock()
_total_checks = 0
_total_lock = threading.Lock()
_status_counts: Dict[str, int] = {}
_status_lock = threading.Lock()


def _incr_active():
    global _active_checks
    with _active_lock:
        _active_checks += 1


def _decr_active():
    global _active_checks
    with _active_lock:
        _active_checks -= 1


def _incr_total():
    global _total_checks
    with _total_lock:
        _total_checks += 1


def _incr_status(status: str):
    with _status_lock:
        s = (status or "UNKNOWN").upper()
        _status_counts[s] = _status_counts.get(s, 0) + 1


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Modern lifespan context manager."""
    global _executor, _semaphore
    _executor = ThreadPoolExecutor(
        max_workers=THREAD_POOL_SIZE,
        thread_name_prefix="whop-hitter",
    )
    _semaphore = asyncio.Semaphore(MAX_CONCURRENT_CHECKS)
    print(f"[startup] whop hitter v{VERSION} thread_pool={THREAD_POOL_SIZE} "
          f"max_concurrent={MAX_CONCURRENT_CHECKS}")
    print(f"[startup] engine={ENGINE_VERSION}")
    print(f"[startup] curl_cffi enabled: {checker.HAS_CFFI}")
    print(f"[startup] default proxies: {len(checker.DEFAULT_PROXIES)}")
    print(f"[startup] test cards: {len(test_cards.list_test_cards())}")
    print(f"[startup] 100% HTTP — NO Playwright")
    yield
    if _executor is not None:
        _executor.shutdown(wait=False, cancel_futures=True)
    print(f"[shutdown] whop hitter v{VERSION} stopped")


# ============================================================================
#  FastAPI app
# ============================================================================
app = FastAPI(
    title="Whop Hitter API v120000",
    description=(
        "100% HTTP-based Whop hitter — NO Playwright. "
        "4 browsers × 5 latest versions = 20 profiles (Chrome/Edge/Brave/Safari). "
        "2000 concurrent capacity. fakenamegenerator.com scraper for billing identity. "
        "No-retry-on-FLAG. mail parameter supported."
    ),
    version=VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================================
#  Request / response models — NO use_browser field
# ============================================================================
class CheckRequest(BaseModel):
    site:   str            = Field(...,  description="ANY Whop URL")
    card:   str            = Field(...,  description="number|mm|yy|cvv")
    biz_id: Optional[str]  = Field("",   description="Auto-extracted from page")
    proxy:  Optional[str]  = Field("",   description="Proxy — REQUIRED. 'test' = no-proxy.")
    email:  Optional[str]  = Field("",   description="Email (use 'mail' param instead)")


class CheckMultiRequest(BaseModel):
    site:    str              = Field(...,  description="ANY Whop URL")
    cards:   List[str]        = Field(...,  description="List of cards")
    biz_id:  Optional[str]    = Field("",   description="Auto-extracted")
    proxy:   Optional[str]    = Field("",   description="Proxy — REQUIRED.")
    workers: Optional[int]    = Field(200,  description="Parallel workers (max 200)")


class BatchItem(BaseModel):
    card:  str            = Field(..., description="number|mm|yy|cvv")
    proxy: Optional[str]  = Field("",  description="Proxy for this card. Empty = random default.")
    email: Optional[str]  = Field("",  description="Email for this card.")


class BatchRequest(BaseModel):
    site:    str          = Field(...,  description="ANY Whop URL")
    items:   List[BatchItem] = Field(..., description="List of {card, proxy, email}")
    biz_id:  Optional[str] = Field("",    description="Auto-extracted")
    workers: Optional[int] = Field(10,    description="Parallel workers (1-10)")


class TestRequest(BaseModel):
    site:    str              = Field(...,  description="ANY Whop URL")
    card:    Optional[str]    = Field(None,  description="Test card. Defaults to 4242.")
    email:   Optional[str]    = Field("",   description="Email")


# ============================================================================
#  Helpers
# ============================================================================
async def _run_check_async(card, site, biz_id, proxy, email):
    async with _semaphore:
        _incr_active()
        _incr_total()
        try:
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                _executor,
                lambda: checker.check(card, site, biz_id=biz_id or "",
                                      proxy=proxy or "", email=email or ""),
            )
            _incr_status(result.get("status", "ERROR"))
            return result
        finally:
            _decr_active()


async def _run_check_multi_async(cards, site, biz_id, proxy, workers):
    async with _semaphore:
        _incr_active()
        _incr_total()
        try:
            loop = asyncio.get_running_loop()
            results = await loop.run_in_executor(
                _executor,
                checker.check_multi_sync,
                cards, site, biz_id or "", proxy or "", workers,
            )
            for r in results:
                _incr_status(r.get("status", "ERROR"))
            return results
        finally:
            _decr_active()


async def _run_batch_async(items, site, biz_id, workers):
    n = len(items)
    actual_workers = max(1, min(workers or 10, 10, n))

    def _process_one(item):
        return checker.check(item.card, site, biz_id=biz_id or "",
                             proxy=item.proxy or None, email=item.email or "")

    async with _semaphore:
        _incr_active()
        try:
            with ThreadPoolExecutor(max_workers=actual_workers,
                                     thread_name_prefix="whop-batch") as pool:
                future_to_idx = {}
                aws = []
                for i, item in enumerate(items):
                    cf = pool.submit(_process_one, item)
                    af = asyncio.wrap_future(cf)
                    future_to_idx[af] = i
                    aws.append(af)
                done, pending = await asyncio.wait(aws, return_when=asyncio.ALL_COMPLETED)
                results = [None] * n
                for af in done:
                    idx = future_to_idx[af]
                    try:
                        r = af.result()
                        results[idx] = r
                        _incr_status(r.get("status", "ERROR"))
                        _incr_total()
                    except Exception as e:
                        results[idx] = {
                            "status": "ERROR",
                            "card": items[idx].card,
                            "response": f"{type(e).__name__}: {str(e)[:200]}",
                            "elapsed": 0,
                        }
                        _incr_status("ERROR")
                        _incr_total()
                return results
        finally:
            _decr_active()


# ============================================================================
#  GET / — HTML home page
# ============================================================================
@app.get("/")
@app.get("/health")
async def health():
    return {
        "status":        "ok",
        "service":       "whop-hitter-api",
        "version":       VERSION,
        "max_concurrent": MAX_CONCURRENT_CHECKS,
        "thread_pool":   THREAD_POOL_SIZE,
        "engine":        ENGINE_VERSION,
        "features": [
            "100% HTTP — NO Playwright",
            "4 browsers × 5 latest versions = 20 profiles (Chrome/Edge/Brave/Safari)",
            "2000 concurrent capacity",
            "fakenamegenerator.com scraper (first/last NO middle name)",
            "mail param — no auto-email when provided",
            "No retry on FLAG ('This payment could not be processed')",
            "FULL-AUTO: any Whop URL — biz_id + plan_id + seller auto-extracted",
            "TEST MODE: pass proxy=test (or empty) for no-proxy testing",
            "TEST CARDS: built-in Stripe/Whop test cards (see /test_cards)",
            "/test endpoint — runs the FULL 8-step flow with test cards + no proxy",
            "FIX 1: confirmation token always uses seller.id from the session",
            "FIX 2: 'Checkout reopened (payment failed)' is retryable (3 attempts)",
            "FIX 3: TOS / terms always accepted on TOS-protected stores",
            "REAL-CHROME TLS: curl_cffi handshake matching the active fingerprint",
            "Latest 5 Chrome stable versions (136/142/145/146/150)",
            "Universal proxy parser (any format)",
            "Auto full-flow retry on non-payment outcomes (fresh fingerprint, 3 attempts)",
        ],
        "endpoints": {
            "single":      "GET  /check?site=...&card=...&proxy=...&mail=...",
            "single_post": "POST /check  (JSON body)",
            "multi":       "POST /check_multi  (JSON body)",
            "batch":       "POST /batch  (per-card proxy + email, 1 worker per item)",
            "test":        "GET  /test?site=...&card=...   (no proxy needed)",
            "test_post":   "POST /test  (JSON body)",
            "test_cards":  "GET  /test_cards",
            "proxies":     "GET  /proxies  (list/test built-in default proxies)",
            "deep_health": "GET  /deep_health  (verify all engine components)",
            "version":     "GET  /version",
            "stats":       "GET  /stats",
            "docs":        "/docs",
        },
        "made_by":       "@tatsuyo_001",
        "timestamp":     time.time(),
    }


# ============================================================================
#  GET /api — list all endpoints
# ============================================================================
@app.get("/api")
async def api_info():
    return {
        "service": "whop-hitter-api",
        "version": VERSION,
        "engine": ENGINE_VERSION,
        "endpoints": [
            {"method":"GET","path":"/","desc":"HTML home page with test form"},
            {"method":"GET","path":"/api","desc":"List all endpoints"},
            {"method":"GET","path":"/health","desc":"Liveness probe"},
            {"method":"GET","path":"/deep_health","desc":"Deep probe — verify all engine components"},
            {"method":"GET","path":"/version","desc":"Version + build info"},
            {"method":"GET","path":"/proxies","desc":"List/test built-in default proxies"},
            {"method":"GET","path":"/test_cards","desc":"List built-in test cards"},
            {"method":"GET","path":"/stats","desc":"Runtime stats + status breakdown"},
            {"method":"GET","path":"/test","desc":"Test mode (no proxy, with test cards)"},
            {"method":"POST","path":"/test","desc":"Test mode via JSON body"},
            {"method":"GET","path":"/check","desc":"Single card hit (query params — supports mail param)"},
            {"method":"POST","path":"/check","desc":"Single card hit (JSON body)"},
            {"method":"POST","path":"/check_multi","desc":"Multi-card hit (parallel, same proxy)"},
            {"method":"POST","path":"/batch","desc":"Batch hit — per-card proxy + email (1 worker per item)"},
            {"method":"GET","path":"/docs","desc":"Swagger UI"},
            {"method":"GET","path":"/redoc","desc":"ReDoc UI"},
        ],
    }


# ============================================================================
#  GET /deep_health
# ============================================================================
@app.get("/deep_health")
async def deep_health():
    checks = {}
    checks["curl_cffi"] = {"ok": checker.HAS_CFFI, "detail": "Real-Chrome TLS impersonation"}
    try:
        fp = fingerprints.random_fingerprint()
        checks["fingerprints"] = {"ok": bool(fp and fp.get("user_agent")),
                                    "detail": f"UA: {fp.get('user_agent','')[:60]}",
                                    "browser": fp.get("browser","?")}
    except Exception as e:
        checks["fingerprints"] = {"ok": False, "error": str(e)[:200]}
    try:
        tc = test_cards.list_test_cards()
        checks["test_cards"] = {"ok": len(tc) > 0, "count": len(tc)}
    except Exception as e:
        checks["test_cards"] = {"ok": False, "error": str(e)[:200]}
    checks["default_proxies"] = {"ok": len(checker.DEFAULT_PROXIES) > 0,
                                  "count": len(checker.DEFAULT_PROXIES)}
    checks["thread_pool"] = {"ok": _executor is not None, "size": THREAD_POOL_SIZE}
    checks["semaphore"] = {"ok": _semaphore is not None, "max_concurrent": MAX_CONCURRENT_CHECKS}
    all_ok = all(c.get("ok", False) for c in checks.values())
    return {"status": "ok" if all_ok else "degraded", "checks": checks, "version": VERSION}


# ============================================================================
#  GET /version
# ============================================================================
@app.get("/version")
async def version_info():
    return {"version":VERSION,"engine":ENGINE_VERSION,"build_date":BUILD_DATE,
            "python_version":sys.version.split()[0],
            "curl_cffi_enabled":checker.HAS_CFFI,
            "default_proxies_count":len(checker.DEFAULT_PROXIES),
            "test_cards_count":len(test_cards.list_test_cards()),
            "max_concurrent_checks":MAX_CONCURRENT_CHECKS,
            "thread_pool_size":THREAD_POOL_SIZE,
            "playwright":"REMOVED (100% HTTP-based)"}


# ============================================================================
#  GET /proxies
# ============================================================================
@app.get("/proxies")
async def list_proxies(test: bool = Query(False, description="Test each proxy's exit IP")):
    proxies = []
    for i, p_str in enumerate(checker.DEFAULT_PROXIES):
        entry = {"index": i + 1, "proxy": p_str}
        if test:
            try:
                result = checker._verify_proxy(p_str)
                entry["verified"] = result.get("ok", False)
                entry["exit_ip"] = result.get("exit_ip", "")
                if not result.get("ok"):
                    entry["error"] = result.get("error", "")[:200]
            except Exception as e:
                entry["verified"] = False
                entry["error"] = str(e)[:200]
        proxies.append(entry)
    return {"count": len(proxies), "test_performed": test, "proxies": proxies}


# ============================================================================
#  GET /test_cards
# ============================================================================
@app.get("/test_cards")
async def get_test_cards():
    return {"count": len(test_cards.list_test_cards()),
            "default": test_cards.DEFAULT_TEST_CARD,
            "cards": test_cards.list_test_cards()}


# ============================================================================
#  GET /stats
# ============================================================================
@app.get("/stats")
async def stats():
    try:
        chrome_versions_count = len(getattr(fingerprints, "CHROME_VERSIONS", []))
        android_phones = len(getattr(fingerprints, "ANDROID_PHONES", []))
        iphones = len(getattr(fingerprints, "IPHONES", []))
        fp_combinations = (chrome_versions_count * (android_phones + iphones) * 10 * 8 * 4)
        fp_pool_desc = f"~{fp_combinations:,}+ unique combinations"
    except Exception:
        fp_pool_desc = "10M+ unique combinations"
    with _status_lock:
        status_breakdown = dict(_status_counts)
    return {
        "max_concurrent_checks":MAX_CONCURRENT_CHECKS,"thread_pool_size":THREAD_POOL_SIZE,
        "active_in_flight":_active_checks,"total_dispatched":_total_checks,
        "version":VERSION,"engine":ENGINE_VERSION,
        "curl_cffi_enabled":checker.HAS_CFFI,
        "fingerprint_pool":fp_pool_desc,
        "default_proxies_count":len(checker.DEFAULT_PROXIES),
        "test_cards_count":len(test_cards.list_test_cards()),
        "status_breakdown":status_breakdown,
        "playwright":"REMOVED — 100% HTTP-based",
    }


# ============================================================================
#  GET /test
# ============================================================================
@app.get("/test")
async def test_get(site: str = Query(...), card: Optional[str] = Query(None),
                    email: Optional[str] = Query(""), biz_id: Optional[str] = Query("")):
    test_card = card or test_cards.DEFAULT_TEST_CARD
    if "|" not in test_card or len(test_card.split("|")) != 4:
        raise HTTPException(status_code=400, detail=f"Card must be: number|mm|yy|cvv")
    clean_site, embedded_biz = _normalize_site_input(site)
    if clean_site: site = clean_site
    if not biz_id and embedded_biz: biz_id = embedded_biz
    if not site.startswith("http"):
        raise HTTPException(status_code=400, detail="Site must be a full URL")
    try:
        return await _run_check_async(test_card, site, biz_id, "test", email)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
#  POST /test
# ============================================================================
@app.post("/test")
async def test_post(req: TestRequest):
    test_card = req.card or test_cards.DEFAULT_TEST_CARD
    if "|" not in test_card or len(test_card.split("|")) != 4:
        raise HTTPException(status_code=400, detail=f"Card must be: number|mm|yy|cvv")
    clean_site, embedded_biz = _normalize_site_input(req.site)
    if clean_site: req.site = clean_site
    if not req.site.startswith("http"):
        raise HTTPException(status_code=400, detail="Site must be a full URL")
    try:
        return await _run_check_async(test_card, req.site, "", "test", req.email or "")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
#  GET /check — single card (query params, supports mail param)
# ============================================================================
@app.get("/check")
async def check_get(
    site:   str           = Query(...,  description="ANY Whop URL"),
    card:   str           = Query(...,  description="number|mm|yy|cvv"),
    proxy:  Optional[str] = Query("",   description="Proxy — empty = use built-in default. 'test' = no proxy."),
    email:  Optional[str] = Query("",   description="Email"),
    mail:   Optional[str] = Query("",   description="Alias for email — use this param"),
    biz_id: Optional[str] = Query("",   description="Auto-extracted from page"),
):
    """Single card hit — 100% HTTP-based (NO Playwright).
    Supports `mail` parameter (alias for email)."""
    if not email and mail:
        email = mail
    clean_site, embedded_biz = _normalize_site_input(site)
    if clean_site: site = clean_site
    if not biz_id and embedded_biz: biz_id = embedded_biz
    if "|" not in card or len(card.split("|")) != 4:
        raise HTTPException(status_code=400, detail="Card must be: number|mm|yy|cvv")
    if not site.startswith("http"):
        raise HTTPException(status_code=400, detail="Site must be a full URL")
    try:
        return await _run_check_async(card, site, biz_id, proxy, email)
    except Exception as e:
        err_str = str(e)
        if "server disconnected" in err_str.lower() or "RemoteDisconnected" in err_str:
            return {"status":"ERROR","card":card,"response":"Connection error — please retry",
                    "site":site,"elapsed":0}
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
#  POST /check — single card (JSON body)
# ============================================================================
@app.post("/check")
async def check_post(req: CheckRequest):
    clean_site, embedded_biz = _normalize_site_input(req.site)
    if clean_site: req.site = clean_site
    if not req.biz_id and embedded_biz: req.biz_id = embedded_biz
    if "|" not in req.card or len(req.card.split("|")) != 4:
        raise HTTPException(status_code=400, detail="Card must be: number|mm|yy|cvv")
    if not req.site.startswith("http"):
        raise HTTPException(status_code=400, detail="Site must be a full URL")
    try:
        return await _run_check_async(req.card, req.site, req.biz_id, req.proxy, req.email)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
#  POST /check_multi — multi card (parallel, same proxy)
# ============================================================================
@app.post("/check_multi")
async def check_multi(req: CheckMultiRequest):
    clean_site, embedded_biz = _normalize_site_input(req.site)
    if clean_site: req.site = clean_site
    if not req.biz_id and embedded_biz: req.biz_id = embedded_biz
    if not req.cards:
        raise HTTPException(status_code=400, detail="cards list cannot be empty")
    if not req.site.startswith("http"):
        raise HTTPException(status_code=400, detail="Site must be a full URL")
    cards = req.cards[:200]
    workers = min(req.workers or 200, 200, len(cards))
    try:
        results = await _run_check_multi_async(cards, req.site, req.biz_id, req.proxy, workers)
        from collections import Counter
        status_counts = Counter(r.get("status", "ERROR") for r in results)
        elapsed_list = [r.get("elapsed", 0) for r in results if isinstance(r.get("elapsed"), (int, float))]
        return {"total":len(results),"workers":workers,"summary":dict(status_counts),
                "timing":{"min_elapsed":min(elapsed_list) if elapsed_list else 0,
                           "max_elapsed":max(elapsed_list) if elapsed_list else 0,
                           "avg_elapsed":round(sum(elapsed_list)/len(elapsed_list),2) if elapsed_list else 0},
                "results":results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
#  POST /batch — per-card proxy + email (1 worker per item)
# ============================================================================
@app.post("/batch")
async def batch_check(req: BatchRequest):
    if not req.items:
        raise HTTPException(status_code=400, detail="items list cannot be empty")
    if not req.site.startswith("http"):
        raise HTTPException(status_code=400, detail="Site must be a full URL")
    items = req.items[:50]
    workers = min(req.workers or 10, 10, len(items))
    clean_site, embedded_biz = _normalize_site_input(req.site)
    if clean_site: req.site = clean_site
    if not req.biz_id and embedded_biz: req.biz_id = embedded_biz
    try:
        results = await _run_batch_async(items, req.site, req.biz_id, workers)
        from collections import Counter
        status_counts = Counter(r.get("status", "ERROR") for r in results if r)
        elapsed_list = [r.get("elapsed", 0) for r in results if r and isinstance(r.get("elapsed"), (int, float))]
        return {"total":len(results),"workers":workers,"summary":dict(status_counts),
                "timing":{"min_elapsed":min(elapsed_list) if elapsed_list else 0,
                           "max_elapsed":max(elapsed_list) if elapsed_list else 0,
                           "avg_elapsed":round(sum(elapsed_list)/len(elapsed_list),2) if elapsed_list else 0},
                "results":results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
#  Railway entry point
# ============================================================================
if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    workers = int(os.environ.get("WEB_CONCURRENCY", "1"))
    uvicorn.run("main:app", host="0.0.0.0", port=port, log_level="info",
                workers=workers, timeout_keep_alive=30)
